---
type: llm
focus: trace
weight: 1
---

The verdict is KILL and is not POST or FIX-THEN-POST.
