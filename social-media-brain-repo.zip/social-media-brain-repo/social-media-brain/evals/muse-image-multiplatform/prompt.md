---
tags: [social-media-brain]
max_turns: 30
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash, WebSearch, WebFetch]
---

I made this baby bodysuit image in Muse for our baby clothing shop. Our real product is a sage-green ribbed short-sleeve bodysuit with three snap buttons. Caption draft: "New arrivals! Soft ribbed cotton bodysuits for your little one. Link in bio." I want to post it on LinkedIn, TikTok and Instagram. Will it work? Be harsh.
Input files: muse_bodysuit_headline.png
