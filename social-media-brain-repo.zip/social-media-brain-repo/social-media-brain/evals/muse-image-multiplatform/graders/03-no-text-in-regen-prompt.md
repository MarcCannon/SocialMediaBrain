---
type: llm
focus: trace
weight: 1
---

Every Muse regeneration prompt states that no text appears in the image and none asks for added headline or caption text on the picture.
