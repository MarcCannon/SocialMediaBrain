---
type: llm
focus: trace
weight: 1
---

Algorithm claims carry confidence tags ([CODE], [OFFICIAL], [REPORTED] or [INFERRED]) and the report lists dated sources, or states that web search was unavailable.
