---
type: llm
focus: trace
weight: 1
---

The report checks whether the garment shown matches the real product (sage green, ribbed, short sleeve, three snaps) and notes anything it could not verify.
