---
type: llm
focus: trace
weight: 1
---

The report does not turn scores into predicted views, reach or engagement numbers.
