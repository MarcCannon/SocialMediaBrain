---
type: llm
focus: trace
weight: 1
---

The report gives a POST, FIX-THEN-POST or KILL verdict and a score per requested platform (LinkedIn, TikTok, Instagram), and the overlay text is flagged and reduces the score, so the verdict is not POST.
