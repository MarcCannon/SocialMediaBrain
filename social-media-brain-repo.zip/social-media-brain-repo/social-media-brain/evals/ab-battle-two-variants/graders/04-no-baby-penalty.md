---
type: llm
focus: trace
weight: 1
---

Neither variant is penalised, vetoed or flagged because a baby appears in it.
