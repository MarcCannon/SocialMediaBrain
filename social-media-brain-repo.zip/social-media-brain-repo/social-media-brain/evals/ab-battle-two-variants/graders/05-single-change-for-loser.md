---
type: llm
focus: trace
weight: 1
---

The output gives the single change that would help the losing variant most.
