---
type: llm
focus: trace
weight: 1
---

The scoreboard has one row per variant (A and B) on Instagram Feed, using the same persona weights for both.
