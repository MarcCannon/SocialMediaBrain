---
type: llm
focus: trace
weight: 1
---

The output states the score gap, names a winner, or says too close to call when the gap is under 0.5, and applies the tie rule to the lower Bouncer risk.
