---
type: llm
focus: trace
weight: 1
---

The output flags that Variant B shows a pink garment while the real product is sage green, as a product-match or misleading-claim risk.
