---
type: llm
focus: trace
weight: 1
---

Any text advice puts words in the caption, first line or alt text and never recommends adding text onto the image.
