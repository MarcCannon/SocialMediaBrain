---
tags: [social-media-brain]
max_turns: 30
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash, WebSearch, WebFetch]
---

Two Muse images for the same baby clothing post. Variant A is a baby in a sage-green bodysuit on a plain cream background. Variant B is a baby in a deep pink bodysuit on a pink background. Same caption for both: "Soft, stretchy and made to be worn all day." Platform: Instagram Feed. Our real product comes in sage green. Which one should I post? Use A/B battle.
Input files: variant_a_clean.png, variant_b_busy.png
