#!/usr/bin/env python3
"""Look for AI-provenance metadata in an image or video file.

Searches the raw bytes for C2PA / Content Credentials markers, IPTC
DigitalSourceType values that mean "made with AI", and XMP packets, and reads
generator names from XMP, EXIF and PNG text chunks. The Bouncer uses it to
predict whether a platform that reads this metadata will auto-label the post.

What it cannot see: invisible pixel watermarks (Meta says Muse / Meta AI
images carry one; Google SynthID and others work the same way) and the
platforms' own classifiers. So "nothing found" does NOT mean the post will go
unlabelled. Screenshots, re-saves and some editors strip metadata; they do not
necessarily remove an invisible watermark.

Usage:
    python scan_provenance.py FILE [FILE ...] [--json]

Exit codes: 0 done, 1 bad input. Pillow is optional (adds EXIF / PNG text).
"""

import argparse
import json
import re
import sys
from pathlib import Path

CHUNK = 8 * 1024 * 1024
OVERLAP = 128

# Exact-case byte markers, long enough that random compressed data will not
# match them by accident.
C2PA_MARKERS = [b"c2pa.claim", b"c2pa.signature", b"c2pa.assertions", b"c2pa.actions"]
JUMBF_RE = re.compile(rb"jumb[\s\S]{4}jumd")
SOURCE_TYPE_RE = re.compile(rb"digitalsourcetype/([a-z]+)(?=[^a-z])")
XMP_START = b"<x:xmpmeta"

AI_SOURCE_TYPES = {
    "trainedalgorithmicmedia": "trainedAlgorithmicMedia (made by generative AI)",
    "compositewithtrainedalgorithmicmedia":
        "compositeWithTrainedAlgorithmicMedia (real media edited with generative AI)",
    "algorithmicmedia": "algorithmicMedia (made by an algorithm)",
    "compositesynthetic": "compositeSynthetic (composite with synthetic elements)",
}

GENERATOR_RE = re.compile(
    r"\b(Meta AI|Imagined with AI|Made with AI|Muse|OpenAI|DALL.?E|ChatGPT|Midjourney|"
    r"Firefly|Stable Diffusion|ComfyUI|Automatic1111|Gemini|Imagen|SynthID|Ideogram|"
    r"Runway|Sora|Kling|Leonardo|Flux|Grok|Veo|Pika|Luma|Hailuo|Recraft|Generative Fill)\b",
    re.IGNORECASE,
)


def scan_bytes(path):
    c2pa_at, jumbf_at = None, None
    source_types = set()
    xmp_offsets = []
    claim_hints = []
    with open(path, "rb") as fh:
        offset, tail = 0, b""
        while True:
            block = fh.read(CHUNK)
            if not block:
                break
            data = tail + block
            base = offset - len(tail)
            if c2pa_at is None:
                hits = [data.find(m) for m in C2PA_MARKERS]
                hits = [h for h in hits if h >= 0]
                if hits:
                    c2pa_at = base + min(hits)
            if jumbf_at is None:
                match = JUMBF_RE.search(data)
                if match:
                    jumbf_at = base + match.start()
            for match in SOURCE_TYPE_RE.finditer(data.lower()):
                source_types.add(match.group(1).decode("ascii"))
            start = data.find(XMP_START)
            while start >= 0 and len(xmp_offsets) < 5:
                if base + start not in xmp_offsets:
                    xmp_offsets.append(base + start)
                start = data.find(XMP_START, start + 1)
            for match in re.finditer(rb"claim_generator", data):
                window = data[match.end(): match.end() + 200]
                runs = [r.decode("ascii") for r in re.findall(rb"[\x20-\x7e]{4,}", window)]
                if runs and len(claim_hints) < 3 and runs[0] not in claim_hints:
                    claim_hints.append(runs[0])
            offset += len(block)
            tail = block[-OVERLAP:]
    return c2pa_at, jumbf_at, source_types, xmp_offsets, claim_hints


def read_xmp(path, offsets):
    packets = []
    with open(path, "rb") as fh:
        for off in offsets:
            fh.seek(off)
            raw = fh.read(512 * 1024)
            end = raw.find(b"</x:xmpmeta>")
            if end >= 0:
                raw = raw[: end + len(b"</x:xmpmeta>")]
            packets.append(raw.decode("utf-8", errors="replace"))
    return packets


def xmp_fields(packets):
    fields = {}
    for packet in packets:
        for key in ("CreatorTool", "softwareAgent", "Credit", "DigitalSourceType"):
            for value in re.findall(rf'{key}(?:="|>)([^"<]{{1,200}})', packet):
                fields.setdefault(f"XMP {key}", [])
                if value not in fields[f"XMP {key}"]:
                    fields[f"XMP {key}"].append(value)
    return fields


def pillow_text(path):
    try:
        from PIL import Image
    except ImportError:
        return {}
    out = {}
    try:
        with Image.open(path) as im:
            exif = im.getexif()
            for tag, name in ((305, "Software"), (270, "ImageDescription"),
                              (315, "Artist"), (33432, "Copyright")):
                value = exif.get(tag)
                if value:
                    out[f"EXIF {name}"] = [str(value)[:200]]
            for key, value in (im.info or {}).items():
                if isinstance(value, str) and value.strip():
                    out[f"text chunk '{key}'"] = [value[:200]]
    except Exception:  # not an image Pillow can read (e.g. a video)
        return {}
    return out


def scan(path):
    c2pa_at, jumbf_at, source_types, xmp_offsets, claim_hints = scan_bytes(path)
    meta = xmp_fields(read_xmp(path, xmp_offsets))
    meta.update(pillow_text(path))
    if claim_hints:
        meta["C2PA claim_generator (raw)"] = claim_hints
    # Free-text credit fields (a photographer named Leonardo) must not count as generators.
    skip = ("Copyright", "Artist", "ImageDescription")
    meta_text = " ".join(v for k, values in meta.items()
                         if not any(s in k for s in skip) for v in values)
    generators = sorted({m.group(1) for m in GENERATOR_RE.finditer(meta_text)}, key=str.lower)
    ai_types = [AI_SOURCE_TYPES[t] for t in sorted(source_types) if t in AI_SOURCE_TYPES]
    other_types = sorted(t for t in source_types if t not in AI_SOURCE_TYPES)

    if c2pa_at is not None or ai_types:
        level = "STRONG"
        prediction = ("Carries machine-readable provenance. Platforms that read C2PA or IPTC "
                      "metadata are likely to auto-apply their AI label. Plan the disclosure; "
                      "see references/ai-content-and-muse.md for each platform's label.")
    elif generators or jumbf_at is not None:
        level = "MEDIUM"
        prediction = ("Generator names or a JUMBF box sit in the metadata. Some platforms may "
                      "read them. Disclose where the platform asks.")
    else:
        level = "NONE FOUND"
        prediction = ("No AI metadata found. That does not mean the post will go unlabelled: "
                      "invisible watermarks and platform classifiers can still trigger a label. "
                      "If the asset is AI-generated, disclose it where the platform asks.")
    return {
        "file": str(path),
        "size_bytes": path.stat().st_size,
        "c2pa_manifest": {"found": c2pa_at is not None, "byte_offset": c2pa_at},
        "jumbf_box": {"found": jumbf_at is not None, "byte_offset": jumbf_at},
        "iptc_ai_source_types": ai_types,
        "iptc_other_source_types": other_types,
        "xmp_packets": len(xmp_offsets),
        "metadata_text": meta,
        "generator_names_in_metadata": generators,
        "signal": level,
        "prediction": prediction,
        "cannot_detect": ("Invisible pixel watermarks and platform classifiers. Absence of "
                          "metadata is not evidence that the asset is unlabelled or human-made."),
    }


def print_report(r):
    mb = r["size_bytes"] / (1024 * 1024)
    print(f"File: {Path(r['file']).name} ({mb:.1f} MB)")
    c2pa = r["c2pa_manifest"]
    print("C2PA / Content Credentials: " +
          (f"found (byte {c2pa['byte_offset']})" if c2pa["found"] else "not found"))
    if r["jumbf_box"]["found"] and not c2pa["found"]:
        print(f"JUMBF box: found (byte {r['jumbf_box']['byte_offset']}), often used for C2PA")
    print("IPTC DigitalSourceType (AI): " + (", ".join(r["iptc_ai_source_types"]) or "none"))
    if r["iptc_other_source_types"]:
        print("IPTC DigitalSourceType (other): " + ", ".join(r["iptc_other_source_types"]))
    print(f"XMP packets: {r['xmp_packets']}")
    for key, values in r["metadata_text"].items():
        print(f"  {key}: {' | '.join(values)}")
    print("Generator names in metadata: " + (", ".join(r["generator_names_in_metadata"]) or "none"))
    print(f"Signal: {r['signal']} - {r['prediction']}")
    print(f"Cannot detect: {r['cannot_detect']}")


def main():
    parser = argparse.ArgumentParser(description="Scan files for AI provenance metadata.")
    parser.add_argument("files", nargs="+", help="image or video files")
    parser.add_argument("--json", action="store_true", help="print JSON instead of text")
    args = parser.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    results, status = [], 0
    for name in args.files:
        path = Path(name)
        if not path.is_file():
            print(f"Not a file: {path}")
            status = 1
            continue
        results.append(scan(path))
    if args.json:
        print(json.dumps(results, indent=2))
    else:
        for i, r in enumerate(results):
            if i:
                print()
            print_report(r)
    return status


if __name__ == "__main__":
    sys.exit(main())
