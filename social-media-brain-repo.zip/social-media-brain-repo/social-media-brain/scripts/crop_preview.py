#!/usr/bin/env python3
"""Preview how an image (or a video frame) crops on each platform.

For one image it writes:
  - a centre crop at each common ratio (9:16, 4:5, 1:1, 2:3, 1.91:1, 3:4)
  - the same crops with the platform UI safe zones shaded
  - a phone-feed thumbnail (about 360 px wide) and a grid thumbnail (about
    120 px wide), to check that the subject still reads
  - contact.png: all crops on one sheet, so you can look at them in one go

Safe-zone numbers are fractions of the frame (top, bottom, left, right). They
are PLACEHOLDERS that mirror what each platform file in references/platforms/
says; the platform file wins if the two disagree. Edit SAFE_ZONES below, or
pass --safe top,bottom,left,right to override for one run.

Usage:
    python crop_preview.py IMAGE [--out DIR] [--safe 0.14,0.35,0.06,0.06]

Needs Pillow. Without Pillow it falls back to ffmpeg (crops and a drawbox
overlay, no contact sheet). With neither, it prints what to do by hand.
Exit codes: 0 done, 1 bad input, 2 no tool available.
"""

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

# name -> (width, height) ratio
RATIOS = {
    "9x16": (9, 16),
    "4x5": (4, 5),
    "1x1": (1, 1),
    "2x3": (2, 3),
    "1.91x1": (191, 100),
    "3x4": (3, 4),  # Instagram profile grid, [REPORTED]; verify in platform file
}

# name -> (ratio key, (top, bottom, left, right) as fractions, note)
# Placeholders. Reels/TikTok numbers are the ones reported at build time; the
# platform files hold the verified figures.
SAFE_ZONES = {
    "reels_9x16": ("9x16", (0.14, 0.35, 0.06, 0.06), "Instagram Reels UI (REPORTED)"),
    "tiktok_9x16": ("9x16", (0.125, 0.34, 0.11, 0.17), "TikTok UI, right rail (REPORTED, ManyPixels 2026-11)"),
    "shorts_9x16": ("9x16", (0.15, 0.35, 0.045, 0.18), "YouTube Shorts UI (REPORTED, Socialync)"),
    "feed_4x5": ("4x5", (0.0, 0.0, 0.0, 0.0), "Instagram feed: no UI overlay"),
    "grid_3x4": ("3x4", (0.0, 0.0, 0.0, 0.0), "Profile grid crop"),
}


def centre_box(w, h, rw, rh):
    """Largest centred box of ratio rw:rh inside w x h."""
    if w * rh >= h * rw:  # image is wider than target
        bh = h
        bw = round(h * rw / rh)
    else:
        bw = w
        bh = round(w * rh / rw)
    left, top = (w - bw) // 2, (h - bh) // 2
    return left, top, left + bw, top + bh


def label(im, text):
    from PIL import ImageDraw
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 8 + 7 * len(text), 16], fill=(0, 0, 0))
    d.text((4, 2), text, fill=(255, 255, 255))
    return im


def shade(im, zone):
    from PIL import Image
    top, bottom, left, right = zone
    w, h = im.size
    over = Image.new("RGBA", im.size, (0, 0, 0, 0))
    from PIL import ImageDraw
    d = ImageDraw.Draw(over)
    red = (255, 0, 0, 90)
    d.rectangle([0, 0, w, round(h * top)], fill=red)
    d.rectangle([0, round(h * (1 - bottom)), w, h], fill=red)
    d.rectangle([0, 0, round(w * left), h], fill=red)
    d.rectangle([round(w * (1 - right)), 0, w, h], fill=red)
    return Image.alpha_composite(im.convert("RGBA"), over).convert("RGB")


def run_pillow(src, out, override):
    from PIL import Image, ImageOps
    Image.MAX_IMAGE_PIXELS = None
    im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
    w, h = im.size
    print(f"Source: {src.name}  {w}x{h}")
    tiles = []
    for name, (rw, rh) in RATIOS.items():
        crop = im.crop(centre_box(w, h, rw, rh))
        path = out / f"crop_{name}.png"
        crop.save(path)
        tiles.append(label(crop.copy(), name))
        print(f"  crop {name}: {crop.size[0]}x{crop.size[1]} -> {path.name}")
    for name, (rkey, zone, note) in SAFE_ZONES.items():
        zone = override if (override and rkey == "9x16") else zone
        if not any(zone):
            continue
        rw, rh = RATIOS[rkey]
        crop = im.crop(centre_box(w, h, rw, rh))
        shaded = shade(crop, zone)
        path = out / f"safe_{name}.png"
        shaded.save(path)
        print(f"  safe zone {name} ({note}): red = covered by UI -> {path.name}")
        tiles.append(label(shaded.copy(), name))
    for tag, width in (("phone_feed", 360), ("grid_thumb", 120)):
        thumb = im.copy()
        thumb.thumbnail((width, width * 4))
        thumb.save(out / f"{tag}.png")
        print(f"  {tag}: {thumb.size[0]}x{thumb.size[1]} -> {tag}.png")
    # contact sheet: scale every tile to height 320, lay out in rows of 4
    rows, row, row_w = [], [], 0
    for t in tiles:
        t = t.resize((max(1, round(t.size[0] * 320 / t.size[1])), 320))
        if row and row_w + t.size[0] > 1400:
            rows.append(row)
            row, row_w = [], 0
        row.append(t)
        row_w += t.size[0] + 8
    if row:
        rows.append(row)
    sheet = Image.new("RGB", (1400, len(rows) * 328), (30, 30, 30))
    for r, row in enumerate(rows):
        x = 0
        for t in row:
            sheet.paste(t, (x, r * 328))
            x += t.size[0] + 8
    sheet.save(out / "contact.png")
    print("  contact sheet -> contact.png")


def run_ffmpeg(src, out, override):
    ff = shutil.which("ffmpeg")
    for name, (rw, rh) in RATIOS.items():
        vf = (f"crop='if(gte(iw/ih,{rw}/{rh}),ih*{rw}/{rh},iw)':"
              f"'if(gte(iw/ih,{rw}/{rh}),ih,iw*{rh}/{rw})'")
        subprocess.run([ff, "-y", "-loglevel", "error", "-i", str(src), "-vf", vf,
                        "-frames:v", "1", str(out / f"crop_{name}.png")], check=False)
        print(f"  crop {name} -> crop_{name}.png")
    for name, (rkey, zone, note) in SAFE_ZONES.items():
        zone = override if (override and rkey == "9x16") else zone
        if not any(zone):
            continue
        rw, rh = RATIOS[rkey]
        top, bottom, left, right = zone
        vf = (f"crop='if(gte(iw/ih,{rw}/{rh}),ih*{rw}/{rh},iw)':"
              f"'if(gte(iw/ih,{rw}/{rh}),ih,iw*{rh}/{rw})',"
              f"drawbox=x=0:y=0:w=iw:h=ih*{top}:color=red@0.35:t=fill,"
              f"drawbox=x=0:y=ih*(1-{bottom}):w=iw:h=ih*{bottom}:color=red@0.35:t=fill,"
              f"drawbox=x=0:y=0:w=iw*{left}:h=ih:color=red@0.35:t=fill,"
              f"drawbox=x=iw*(1-{right}):y=0:w=iw*{right}:h=ih:color=red@0.35:t=fill")
        subprocess.run([ff, "-y", "-loglevel", "error", "-i", str(src), "-vf", vf,
                        "-frames:v", "1", str(out / f"safe_{name}.png")], check=False)
        print(f"  safe zone {name} -> safe_{name}.png")
    for tag, width in (("phone_feed", 360), ("grid_thumb", 120)):
        subprocess.run([ff, "-y", "-loglevel", "error", "-i", str(src), "-vf",
                        f"scale={width}:-2", "-frames:v", "1", str(out / f"{tag}.png")], check=False)
        print(f"  {tag} -> {tag}.png")
    print("  (no contact sheet without Pillow: open the files one by one)")


def main():
    p = argparse.ArgumentParser(description="Preview platform crops and safe zones.")
    p.add_argument("image")
    p.add_argument("--out", help="output folder (default ./brain_crops/<name>)")
    p.add_argument("--safe", help="override safe zone as top,bottom,left,right fractions")
    args = p.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    src = Path(args.image)
    if not src.is_file():
        print(f"Not a file: {src}")
        return 1
    override = None
    if args.safe:
        try:
            override = tuple(float(x) for x in args.safe.split(","))
            assert len(override) == 4 and all(0 <= v < 0.5 for v in override)
        except Exception:
            print("--safe needs four fractions below 0.5, e.g. 0.14,0.35,0.06,0.06")
            return 1
    out = Path(args.out) if args.out else Path("brain_crops") / src.stem
    out.mkdir(parents=True, exist_ok=True)
    try:
        import PIL  # noqa: F401
        try:
            run_pillow(src, out, override)
        except Exception as exc:
            print(f"Pillow could not read {src.name}: {exc}")
            return 1
    except ImportError:
        if shutil.which("ffmpeg"):
            print("Pillow not installed; using ffmpeg.")
            run_ffmpeg(src, out, override)
        else:
            print("FALLBACK: neither Pillow nor ffmpeg is available.\n"
                  "Ask the user for screenshots of the post in the phone feed and on the "
                  "profile grid, or describe the centre crop at 4:5, 9:16 and 1:1 in text "
                  "and say these crops were not generated.")
            return 2
    print(f"\nWrote files to {out}\n"
          "Safe-zone shading is a placeholder from this script; use the platform file's "
          "numbers when they differ.\nNext: open contact.png, phone_feed.png and "
          "grid_thumb.png and look at them before scoring.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
