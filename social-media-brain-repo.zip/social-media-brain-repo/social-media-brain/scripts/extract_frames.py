#!/usr/bin/env python3
"""Pull the frames and facts a reviewer needs from a short video.

Social Media Brain runs this so the personas judge real pixels, not a guess.
It saves frames at 0s, 1s, 3s, the midpoint and the very end, builds a
contact sheet, finds scene cuts (for the pacing check) and measures audio
levels.

Usage:
    python extract_frames.py VIDEO [--out DIR] [--scene-threshold 0.3]
                             [--no-scenes] [--no-audio]

Needs ffmpeg and ffprobe on PATH. Pillow is optional: with it the contact
sheet gets labels, without it ffmpeg builds an unlabelled one.

Exit codes: 0 done, 1 bad input, 2 ffmpeg/ffprobe not installed.

Audio figures are loudness levels only. Nothing here listens to or
transcribes speech or music, so never report them as having heard the audio.
"""

import argparse
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

COMMON_RATIOS = {
    "9:16": 9 / 16,
    "2:3": 2 / 3,
    "3:4": 3 / 4,
    "4:5": 4 / 5,
    "1:1": 1.0,
    "4:3": 4 / 3,
    "16:9": 16 / 9,
    "1.91:1": 1.91,
}

FALLBACK = (
    "ffmpeg/ffprobe were not found on PATH, so frames cannot be extracted here.\n"
    "Fallback: ask the user for screenshots of the first frame, a frame at about 1s,\n"
    "the middle frame and the last frame, plus the script or voiceover text and\n"
    "the video length. Install ffmpeg (https://ffmpeg.org/download.html) to use this script."
)


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")


def ok(path):
    return path.exists() and path.stat().st_size > 0


def parse_rate(value):
    try:
        num, _, den = str(value).partition("/")
        num, den = float(num), float(den or 1)
        return round(num / den, 3) if den else None
    except ValueError:
        return None


def nearest_ratio(width, height):
    ratio = width / height
    name, target = min(COMMON_RATIOS.items(), key=lambda kv: abs(kv[1] - ratio))
    return name, round(ratio, 4), round(abs(target - ratio) / target * 100, 1)


def rotation_of(stream):
    tags = stream.get("tags") or {}
    if "rotate" in tags:
        try:
            return int(float(tags["rotate"]))
        except ValueError:
            pass
    for side in stream.get("side_data_list") or []:
        if "rotation" in side:
            try:
                return int(float(side["rotation"]))
            except (TypeError, ValueError):
                pass
    return 0


def probe(ffprobe, path):
    result = run([ffprobe, "-v", "error", "-show_format", "-show_streams",
                  "-of", "json", str(path)])
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "ffprobe could not read the file")
    data = json.loads(result.stdout or "{}")
    fmt = data.get("format") or {}
    streams = data.get("streams") or []
    video = next((s for s in streams if s.get("codec_type") == "video"
                  and not (s.get("disposition") or {}).get("attached_pic")), None)
    audio = next((s for s in streams if s.get("codec_type") == "audio"), None)
    duration = None
    for value in (fmt.get("duration"), (video or {}).get("duration")):
        try:
            duration = float(value)
            break
        except (TypeError, ValueError):
            continue
    return fmt, video, audio, duration


def is_still_image(fmt):
    names = (fmt.get("format_name") or "").split(",")
    return any(n == "image2" or n.endswith("_pipe") for n in names)


def frame_plan(duration):
    points = sorted([("first", 0.0), ("1s", 1.0), ("3s", 3.0), ("mid", duration / 2)],
                    key=lambda p: p[1])
    plan = []
    for label, t in points:
        if t > duration - 0.15:
            continue  # too close to the end; the "last" frame covers it
        if plan and abs(t - plan[-1][1]) < 0.25:
            continue
        plan.append((label, round(t, 2)))
    return plan


def grab_frame(ffmpeg, src, t, dest):
    if dest.exists():
        dest.unlink()
    run([ffmpeg, "-v", "error", "-y", "-ss", f"{t:.3f}", "-i", str(src),
         "-an", "-frames:v", "1", "-q:v", "2", str(dest)])
    return ok(dest)


def grab_last(ffmpeg, src, duration, dest):
    if dest.exists():
        dest.unlink()
    back = max(0.1, min(1.0, duration))
    run([ffmpeg, "-v", "error", "-y", "-sseof", f"-{back:.3f}", "-i", str(src),
         "-an", "-update", "1", "-q:v", "2", str(dest)])
    if ok(dest):
        return True
    return grab_frame(ffmpeg, src, max(duration - 0.1, 0.0), dest)


def label_font(size):
    from PIL import ImageFont
    try:
        return ImageFont.load_default(size=size)
    except (TypeError, OSError):
        return ImageFont.load_default()


def contact_sheet(ffmpeg, frames, dest, height=480):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return contact_sheet_ffmpeg(ffmpeg, frames, dest, height), "ffmpeg (unlabelled)"
    lanczos = getattr(Image, "Resampling", Image).LANCZOS
    tiles = []
    for f in frames:
        try:
            with Image.open(f["path"]) as im:
                rgb = im.convert("RGB")
        except Exception:
            return contact_sheet_ffmpeg(ffmpeg, frames, dest, height), "ffmpeg (unlabelled)"
        width = max(1, round(rgb.width * height / rgb.height))
        tiles.append((rgb.resize((width, height), lanczos), f"{f['label']}  {f['time_s']:.2f}s"))
    pad, label_h = 10, 34
    sheet = Image.new("RGB", (sum(t.width for t, _ in tiles) + pad * (len(tiles) + 1),
                              height + label_h + 2 * pad), "white")
    draw = ImageDraw.Draw(sheet)
    font = label_font(22)
    x = pad
    for tile, label in tiles:
        sheet.paste(tile, (x, pad))
        draw.text((x + 4, height + pad + 6), label, fill="black", font=font)
        x += tile.width + pad
    sheet.save(dest, quality=90)
    return ok(dest), "Pillow"


def contact_sheet_ffmpeg(ffmpeg, frames, dest, height):
    cmd = [ffmpeg, "-v", "error", "-y"]
    for f in frames:
        cmd += ["-i", f["path"]]
    n = len(frames)
    if n == 1:
        graph = f"[0:v]scale=-2:{height}[out]"
    else:
        scaled = ";".join(f"[{i}:v]scale=-2:{height}[v{i}]" for i in range(n))
        graph = scaled + ";" + "".join(f"[v{i}]" for i in range(n)) + f"hstack=inputs={n}[out]"
    cmd += ["-filter_complex", graph, "-map", "[out]", "-frames:v", "1", "-q:v", "2", str(dest)]
    run(cmd)
    return ok(dest)


def scene_cuts(ffmpeg, src, threshold, duration):
    result = run([ffmpeg, "-hide_banner", "-nostats", "-i", str(src), "-an", "-sn",
                  "-vf", f"select='gt(scene,{threshold})',showinfo", "-f", "null", "-"])
    if result.returncode != 0:
        return None
    times = sorted({round(float(t), 2) for t in re.findall(r"pts_time:\s*([0-9.]+)", result.stderr)})
    count = len(times)
    return {
        "threshold": threshold,
        "count": count,
        "times_s": times,
        "first_cut_s": times[0] if times else None,
        "cuts_in_first_3s": sum(1 for t in times if t <= 3.0),
        "avg_shot_s": round(duration / (count + 1), 2),
        "note": "Heuristic: misses soft cuts and dissolves; flashes or fast motion can count as cuts.",
    }


def audio_levels(ffmpeg, src, duration):
    result = run([ffmpeg, "-hide_banner", "-nostats", "-i", str(src), "-vn", "-sn",
                  "-af", "silencedetect=noise=-45dB:d=0.4,volumedetect", "-f", "null", "-"])
    if result.returncode != 0:
        return None
    err = result.stderr

    def db(name):
        match = re.search(rf"{name}:\s*(-?inf|-?[0-9.]+) dB", err)
        if not match or "inf" in match.group(1):
            return None
        return float(match.group(1))

    starts = [float(x) for x in re.findall(r"silence_start:\s*(-?[0-9.]+)", err)]
    ends = [float(x) for x in re.findall(r"silence_end:\s*(-?[0-9.]+)", err)]
    silences = []
    for i, start in enumerate(starts):
        end = ends[i] if i < len(ends) else duration
        silences.append([round(max(start, 0.0), 2), round(end, 2)])
    leading = silences[0][1] if silences and silences[0][0] <= 0.05 else 0.0
    mean = db("mean_volume")
    return {
        "mean_db": mean,
        "max_db": db("max_volume"),
        "silent_stretches_s": silences,
        "leading_silence_s": round(leading, 2),
        "note": "Levels only (dBFS). Nothing listened to the speech or music.",
    }


def main():
    parser = argparse.ArgumentParser(description="Extract key frames and facts from a video.")
    parser.add_argument("video", help="path to the video file")
    parser.add_argument("--out", help="output folder (default: ./brain_frames/<video name>)")
    parser.add_argument("--scene-threshold", type=float, default=0.3,
                        help="scene-change sensitivity, 0-1 (default 0.3; lower finds more cuts)")
    parser.add_argument("--no-scenes", action="store_true", help="skip scene-cut detection")
    parser.add_argument("--no-audio", action="store_true", help="skip audio level analysis")
    args = parser.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")

    src = Path(args.video)
    if not src.is_file():
        print(f"Not a file: {src}")
        return 1
    ffmpeg, ffprobe = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if not ffmpeg or not ffprobe:
        print(FALLBACK)
        return 2

    try:
        fmt, video, audio, duration = probe(ffprobe, src)
    except (RuntimeError, json.JSONDecodeError) as exc:
        print(f"Could not read {src.name}: {exc}")
        return 1
    if video is None:
        print("No video stream found. For audio-only files ask for the script; "
              "for a still image use crop_preview.py.")
        return 1
    if is_still_image(fmt) or not duration or duration <= 0:
        print("This looks like a still image, not a video. Use crop_preview.py instead.")
        return 1

    out = Path(args.out) if args.out else Path.cwd() / "brain_frames" / src.stem
    out.mkdir(parents=True, exist_ok=True)
    warnings = []

    width, height = int(video.get("width") or 0), int(video.get("height") or 0)
    rotation = rotation_of(video)
    disp_w, disp_h = (height, width) if abs(rotation) % 180 == 90 else (width, height)
    ratio_name = ratio_val = ratio_off = None
    if disp_w and disp_h:
        ratio_name, ratio_val, ratio_off = nearest_ratio(disp_w, disp_h)
    fps = parse_rate(video.get("avg_frame_rate")) or parse_rate(video.get("r_frame_rate"))

    frames = []
    for index, (label, t) in enumerate(frame_plan(duration), start=1):
        dest = out / f"frame_{index:02d}_{label}_{t:.2f}s.jpg"
        if grab_frame(ffmpeg, src, t, dest):
            frames.append({"label": label, "time_s": t, "file": dest.name, "path": str(dest)})
        else:
            warnings.append(f"could not extract the {label} frame at {t:.2f}s")
    if duration >= 0.5:
        last_t = round(max(duration - 0.04, 0.0), 2)
        dest = out / f"frame_{len(frames) + 1:02d}_last_{last_t:.2f}s.jpg"
        if grab_last(ffmpeg, src, duration, dest):
            frames.append({"label": "last", "time_s": last_t, "file": dest.name, "path": str(dest)})
        else:
            warnings.append("could not extract the last frame")
    if not frames:
        print("No frames could be extracted. Ask the user for screenshots instead.")
        return 1

    sheet_ok, sheet_engine = contact_sheet(ffmpeg, frames, out / "contact_sheet.jpg")
    if not sheet_ok:
        warnings.append("contact sheet could not be built; open the frames one by one")

    cuts = None
    if not args.no_scenes:
        cuts = scene_cuts(ffmpeg, src, args.scene_threshold, duration)
        if cuts is None:
            warnings.append("scene-cut detection failed")

    levels = None
    if audio and not args.no_audio:
        levels = audio_levels(ffmpeg, src, duration)
        if levels is None:
            warnings.append("audio level analysis failed")

    facts = {
        "source": src.name,
        "out_dir": str(out.resolve()),
        "file_size_bytes": src.stat().st_size,
        "duration_s": round(duration, 2),
        "width": width,
        "height": height,
        "rotation_deg": rotation,
        "display_width": disp_w,
        "display_height": disp_h,
        "aspect_ratio": {"nearest": ratio_name, "value": ratio_val, "off_by_pct": ratio_off},
        "fps": fps,
        "video_codec": video.get("codec_name"),
        "has_audio": audio is not None,
        "audio_codec": (audio or {}).get("codec_name"),
        "audio_levels": levels,
        "frames": [{k: v for k, v in f.items() if k != "path"} for f in frames],
        "contact_sheet": "contact_sheet.jpg" if sheet_ok else None,
        "scene_cuts": cuts,
        "warnings": warnings,
        "notes": [
            "Open and look at every frame and the contact sheet before scoring.",
            "Audio figures are levels only; the audio itself was not heard or transcribed.",
        ],
    }
    (out / "facts.json").write_text(json.dumps(facts, indent=2), encoding="utf-8")

    ratio_txt = "unknown ratio"
    if ratio_name:
        ratio_txt = f"{ratio_name}" + (" exact" if ratio_off <= 1 else f", {ratio_off}% off")
    audio_txt = f"audio: {facts['audio_codec']}" if audio else "no audio track"
    print(f"Video: {src.name}  {duration:.2f}s  {disp_w}x{disp_h} ({ratio_txt})  "
          f"{fps or '?'} fps  {facts['video_codec']}  {audio_txt}")
    print(f"Frames: {len(frames)} saved to {out}")
    for f in frames:
        print(f"  {f['label']:<6} {f['time_s']:>7.2f}s  {f['file']}")
    if sheet_ok:
        print(f"Contact sheet: contact_sheet.jpg ({sheet_engine})")
    if cuts:
        first = f"{cuts['first_cut_s']:.2f}s" if cuts["first_cut_s"] is not None else "none"
        print(f"Cuts (scene > {cuts['threshold']}): {cuts['count']}; avg shot {cuts['avg_shot_s']}s; "
              f"first cut {first}; {cuts['cuts_in_first_3s']} in first 3s")
    if levels:
        mean = "silent" if levels["mean_db"] is None else f"{levels['mean_db']} dB"
        print(f"Audio levels: mean {mean}, max {levels['max_db']} dB, "
              f"leading silence {levels['leading_silence_s']}s (levels only - audio was not heard)")
    for w in warnings:
        print(f"Warning: {w}")
    print("Facts: facts.json")
    print("Next: open each frame and the contact sheet and look at them before scoring.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
