# Brand profile (fill once, reuse every run)

The Crowd builds its 3 audience members from this, and the Radar uses it to pick the niche. Skip anything you do not know; the skill asks only for what is missing.

```
Account / brand name:
Platforms and handles:
Niche (one line):
Product category (for example baby clothing):
AI-generated babies or children in images are expected for this brand: yes | no
Product details every image must match (colours, cuts, prints, fabrics, sizes):
Text printed on the product that may appear in images:
Follower counts per platform:
Region and language:
Who follows you and why (2-3 sentences):
Voice (3 adjectives, plus words you never use):
Goal right now: reach | followers | clicks | sales | leads
Best past posts (links or descriptions) and what they had in common:
Worst past posts:
Topics and claims that are off limits:
Real people, brands or places you must not depict:
Do you disclose AI use today? How?
Posting capacity (posts per week, video or image only):
Analytics you can share (best times, top formats):
```
