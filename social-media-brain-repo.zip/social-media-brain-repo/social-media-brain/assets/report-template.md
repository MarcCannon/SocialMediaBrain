# Report template (Full Brain)

Fill every section. Keep the whole report to about 1,500 words; push detail into the per-platform blocks. Every algorithm claim carries a tag: `[CODE]`, `[OFFICIAL]`, `[REPORTED]`, `[INFERRED]`. A report with no tags fails the integrity check. Never turn scores into views, reach or engagement numbers.

```
# Social Media Brain report: <asset name>
Date: <today>   Mode: Full Brain   Web search: <on | off (Radar capped at 6)>
Asset seen: <image | video frames | text only>. Not seen / not heard: <list>

## Verdict
<POST | FIX-THEN-POST | KILL> - best platform: <name> (Brain Score n.n)
Why this will flop (one or two sentences, the Brain's summary of the five openings):
<text>

## Scoreboard
| Platform | Ranker | Thumb | Radar | Crowd | Raw | Bouncer | Multiplier | Brain Score | Verdict |
|---|---|---|---|---|---|---|---|---|---|
| ... |

Caps applied: none | <e.g. score of 8+ capped at 7, no comparable found>
Veto: none | <flag, evidence, fix exists yes/no>
Platforms not scored in full (one-line fit each): <platform: line>

## Asset Sheet
- In frame: ...
- On-image text (verbatim; any burned-in overlay or caption text is a defect; the post's caption field is fine, product print or labels are allowed): ...
- Product match (product posts): does the garment shown match the real product (colour, cut, print)? ...
- Ratio / length / resolution: ...
- First frame and first line: ...
- Watermarks or logos: ...
- Provenance scan: <signal level, or "not run">

## Trend Brief (Radar)
| # | Source | Date | What it says | Link |
|---|---|---|---|---|
Comparable posts: <name + link + why comparable> or "none found"

## Persona scorecards
One block per persona per scored platform, in the shape from references/personas.md. Keep each to 5-8 lines. Crowd lists its 3 members, one line each.

## Cross-fire (Round 2)
- Ranker vs Crowd: ...
- Thumb vs Radar: ...
- Bouncer audit: <unsupported claims removed or downgraded>
- Score changes and reasons: <persona, platform, old -> new, reason>

## Top 3 fixes (ranked by impact)
1. <fix> - moves <platform> from n.n to about n.n  [only if it crosses a verdict line, say so]
2. ...
3. ...

## Rewrites per platform
For each scored platform: hook | caption | hashtags or search keywords | alt text | native format and ratio

## Muse regeneration prompts
One prompt per visual fix, built with references/muse-prompting.md.

## First-hour plan
- Minute 0-5: ...
- Minute 5-30: ...
- Minute 30-60: ...

## Best platform and window
<platform, window> - weak evidence, check the account's own analytics first.

## Sources
<dated list, newest first, with confidence tags>
```

## Quick Check variant
Verdict line, one scoreboard row, top 3 fixes, one rewrite. Under 400 words.

## A/B Battle variant
Scoreboard with one row per variant on the same platform and weights, the gap, "too close to call" if under 0.5 (tie goes to the lower Bouncer risk), and the single change that would help the loser most.

## Post-mortem variant
Predicted vs actual (the user's numbers, quoted as given), what the prediction got right and wrong, which persona was off, and a calibration log entry:

```
Date | Platform | Brain Score | Verdict | Actual result (user's words) | Persona that was off | Lesson
```

Hand the entry to the user to keep. Never write it inside the skill folder.
