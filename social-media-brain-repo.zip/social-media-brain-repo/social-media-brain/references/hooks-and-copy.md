# Hooks and copy

Use this when writing the per-platform rewrites. Caption cut-offs, hashtag norms and length limits live in each platform file; this file holds the patterns. Hooks are patterns to adapt, never to paste: a hook that fits any brand fails the Crowd's generic-message flag.

## Rules
- The hook is the first frame, first line or first slide. It must work with the sound off and at phone size.
- **Never put text on the image.** The image shows the subject; the words live in the caption's first line, the alt text, the platform's title field or the spoken script. The only exception is text that is part of the product (a print on a onesie, a tag, packaging).
- One idea per post. If the rewrite needs "and also", split it.
- Name a specific thing: a number, a person, a place, an object. Vague nouns lose.
- The payoff must match the hook. A hook that overpromises drives swipe-aways `[INFERRED]`.
- Never write engagement bait ("like if you agree", "comment YES", "tag a friend to win"). Platforms penalise it and the Ranker flags it.

## Banned openers
"In today's video", "Hey guys", "Welcome back", "So I wanted to share", "Have you ever wondered", "Let's talk about", "Here's the thing", "Unpopular opinion:" as a bare opener, and any greeting that delays the subject.

## Hook bank by format
**Video opener (first 1-3 s)**
- Start on the result, then rewind: show the finished thing in frame 1.
- A concrete claim with a number: "I changed one setting and cut X in half".
- A visual contradiction: the frame shows something that does not match the caption's first line.
- A direct question about a pain the audience has right now, not a general one.
- A pattern break: unexpected object, motion or colour in the first frame.

**First line of a text post (X, Threads, LinkedIn, Facebook)**
- The stake first: what the reader loses or gains.
- A before/after in one sentence.
- A confession with a specific detail.
- A counter-intuitive claim you can back in the next two lines.
- On LinkedIn and Facebook, the first line must make sense before the "see more" cut.

**Carousel slide 1 / document cover**
- A promise with a number ("7 slides, one fix each").
- A question the last slide answers.
- A bold claim plus "swipe" tension, not the word "swipe" alone.
- One idea per slide after that; the last slide earns a save (checklist, template, summary).

**Pin title / cover (Pinterest)**
- Lead with the search keyword people type, then the benefit, in the Pin title and description fields, not on the image.
- The image reads at grid size on its own: one clear subject, plain background.

**Thumbnail / cover frame**
- One subject, high contrast, no overlay text, outside the UI safe zones. The title or first line of the caption carries the words.

## Caption patterns
- **Context + payoff:** one line of setup, one line of result, one question that has a real answer.
- **Story in three:** what happened, what it cost, what changed.
- **List:** a number in the first line, then the items, then the save reason.
- **Question that names a person:** "Who in your team still does X by hand?" invites a send or a tag naturally, not as bait.

## Calls to action
- Ask for one action. Prefer the platform's top-ranked signal for that platform (see its file): a reply on Threads, a send on Instagram, a save on Pinterest.
- Give the reason: "Save this for your next X" beats "save".
- Links: put them where the platform file says is safe (often the first reply or a native link field). Tag the penalty claim as reported.

## Hashtags and keywords
Use only what the Radar found in live search or on-platform suggestions. No fixed count: follow each platform file's norm. Never copy a hashtag block from an old post.

## Alt text
Describe what is in the image and any text in it, in one or two plain sentences. Do not start with "image of". Include the keyword only if it is true to the picture.

## Cross-posting
Remove other apps' watermarks, re-cut for each ratio, rewrite the hook and caption per platform. Never post one caption everywhere.
