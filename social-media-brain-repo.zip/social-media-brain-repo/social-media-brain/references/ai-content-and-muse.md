# AI content and Muse

last_verified: 2026-11-25
Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

The Bouncer reads this file on every run. Per-platform label rules also appear in each `platforms/<name>.md`; where they differ, the platform file's dated entry wins.

## Contents
1. Muse facts
2. Provenance: what Muse writes into a file
3. Artifact checklist
4. Product accuracy (baby clothing and other products)
5. Babies and children
6. Text on the image
7. Likeness rule
8. Label and disclosure rules per platform
9. What no source says
10. Never claim

## 1. Muse facts
- Muse Image launched 2026-07-07 from Meta Superintelligence Labs. Live in the Meta AI app, meta.ai, Instagram Stories (US, 30+ AI effects) and WhatsApp in a limited set of countries. [OFFICIAL] about.fb.com, 2026-07-07
- Facebook, Messenger and Advantage+ creative were described as "coming later", with no date. Never say Muse is on Facebook. [OFFICIAL] 2026-07-07
- Muse Video is an early preview, not generally available, as of 2026-11-25. If the user says "Muse video", ask whether it is preview access or a Muse Image still animated in another tool. [OFFICIAL] ai.meta.com 2026-07-07; [REPORTED] searched 2026-11-25
- Muse could take public Instagram accounts as prompt input; Meta removed that on 2026-07-10. An image made before then from a real account is a likeness risk (section 7). [OFFICIAL] about.fb.com, 2026-07-10 update

## 2. Provenance: what Muse writes into a file
- Muse Image output carries Content Seal, an invisible watermark Meta says survives crops, compression and screenshots. Video watermarking was "coming soon". [OFFICIAL] ai.meta.com, 2026-07-07
- Meta's launch posts do not mention C2PA or IPTC metadata for Muse. Engadget reports Content Seal is not compatible with C2PA or SynthID, and there is no visible mark. [OFFICIAL - absence]; [REPORTED] Engadget 2026-07-07
- Consequence: platforms that auto-label from C2PA or IPTC (TikTok, YouTube, Pinterest, Meta's own metadata path) may not detect Muse output. Self-label realistic content; do not rely on auto-detection. [INFERRED]
- `scripts/scan_provenance.py` looks for C2PA, IPTC and EXIF generator hints in the file. A clean scan proves nothing: Content Seal is invisible and the script cannot read it. Meta's detector preview is at meta.ai/identification. [OFFICIAL]
- Never help remove, hide or crop out a label or watermark.

## 3. Artifact checklist (run on the real pixels)
Mark each: clean, suspect (region named), or defect. Quote the region ("lower-left third").
- Hands and fingers: count, merging, extra joints. Babies' hands and feet are a common failure.
- Faces: eyes (gaze direction, pupils), teeth, ears, hairline, mismatched sides.
- Garment and fabric: seams that vanish, buttons or snaps that change count, fabric that merges with skin or a blanket, pattern that drifts.
- Impossible physics: shadows that disagree, floating objects, reflections that do not match.
- Over-smooth "AI sheen": waxy skin, uniform sharpness, no real grain.
- Duplicated background elements, repeating patterns, warped straight lines.
- Rendered text anywhere: garbled letters, invented words (section 6).
- Logos, brands and real places that were not meant to be there.
- Video only: lip sync (if audio exists), motion warping on fast movement, objects that change between cuts. Never claim to have heard audio that was not provided.

## 4. Product accuracy (product posts)
An AI image of a product the customer cannot buy is a misleading claim. For every product post, compare the image to the real product (the brand profile, the user's description or a product photo):
- colour (name the shade, and say if lighting shifts it), cut, neckline, sleeve length, closures, trim, print, fabric look;
- count of buttons, snaps, pockets, straps;
- size cues (a "newborn" garment on a toddler-sized body).
A mismatch is a Bouncer deduction on criterion 4, and a veto if it is material (wrong colour or feature the buyer would notice) and cannot be fixed by a caption. The fix is a Muse regeneration prompt with the exact product description (see `muse-prompting.md`, example 1b), or the real product photo.
If no real-product description exists, ask once; if still none, say the match was not checked.

## 5. Babies and children
- AI-generated babies and children showing the product are expected for baby and kids brands. They are never a flag, a deduction or a reason to ask for removal.
- What the Bouncer does check: realism artifacts (section 3); an ordinary, safe presentation (no sexualised or suggestive framing, no unsafe sleep or use staging for products like sleepsacks, no health or developmental claims); and the platform's AI-label rule for realistic people (section 8).
- Child-safety rules at platforms are about real children, abuse and sexualised content. They are not rules against ordinary product imagery. Do not cite them against a normal clothing shot. Pinterest even lists children's fashion as a category for its AI-label controls. [REPORTED] platforms/pinterest.md
- A real, identifiable child needs a consenting parent or guardian. An AI-generated baby needs no consent.

## 6. Text on the image
- Rule: no headlines, captions, slogans, calls to action, stickers or arrows on the image. The hook lives in the caption's first line, the alt text, the platform's title field or the spoken script.
- Allowed: text that is part of the product (a print on a bodysuit, a tag, packaging). It must be legible and spelled correctly.
- Generated text is the commonest Muse failure, so check each letter of any product text.
- Any overlay text that is not product text is a defect: Thumb scores it down, Bouncer flags it. Never recommend adding overlay text; the fix for a weak image is a stronger subject, framing or light.

## 7. Likeness rule
- A real, identifiable person in a Muse image (a celebrity, an influencer, a private individual) without consent is a veto on every platform, label or not. [INFERRED, with the platform rules below]
- It is worse when the post implies endorsement of a product: false endorsement is a misleading claim as well. [INFERRED]
- If an Instagram account or a real person's name informed the Muse prompt, treat the output as that person's likeness.
- Fix when one exists: regenerate with a fictional person or a generic description, drop the endorsement claim, and rewrite the caption. If the likeness is the whole idea, the verdict is KILL for this version.
- Instagram labels AI-persona accounts from 2026-08-31 and removes recommendations from undisclosed ones. That is about accounts that present an AI character as a person; a brand using AI product models is not that, but say so in the disclosure line. [OFFICIAL] creators.instagram.com, 2026-08-31

## 8. Label and disclosure rules per platform
| Platform | What it does | Reach effect | Source |
|---|---|---|---|
| Instagram, Facebook, Threads | "AI info" label from C2PA or IPTC signals or self-disclosure. Realistic video and audio must be self-disclosed; penalties possible. | No Meta source says the label itself lowers reach. | [OFFICIAL] about.fb.com 2024-02-06 and 2024-04-05 |
| Instagram | Stops recommending accounts that mostly repost others' work (2026-04-30). A watermark does not make a post original. AI-persona accounts without disclosure lose recommendations (2026-08-31). | Account-level, not per post. | [OFFICIAL] creators.instagram.com |
| TikTok | Creators must label realistic AIGC (effective 2026-09-24). Auto-labels C2PA uploads. Unlabeled realistic content can be removed, restricted or labeled. | No source says the label cuts reach; viewers can test a "see less AI" control. | [OFFICIAL] tiktok.com guidelines 2026-08-25 |
| YouTube | "AI use" disclosure; since May 2026 automatic labels from C2PA and detection. | The label alone does not affect recommendations or monetization. Repeated non-disclosure can lead to forced labels, removal or a YPP penalty. | [OFFICIAL] YouTube blog 2026-05-27, help page 14328491 |
| Pinterest | "AI modified" label from IPTC metadata and classifiers, appealable. Users can choose to see fewer AI Pins, per category. | No source says the label cuts reach; the user control can. | [OFFICIAL] help.pinterest.com; [REPORTED] (undated, re-check) |
| Bluesky | No AI label or AI rule found. | n/a | [OFFICIAL] |
| X, LinkedIn | See the platform files for current wording; no AI-specific reach penalty found in the sources read. | Not documented. | see `platforms/x.md`, `platforms/linkedin.md` |
| Ads (Meta) | Separate AI-info disclosure rules, updated 2026-06-01. | n/a | [REPORTED] (secondary, unverified) |

Default advice for realistic Muse people or scenes: label on every platform that offers it. Label on a clearly stylised or product-only image is optional but harmless. [INFERRED]

## 9. What no source says
- Whether Muse writes C2PA or IPTC metadata at all.
- Whether Meta's "AI info" label fires automatically on Muse Image posts.
- Whether TikTok detects Content Seal.
- When Muse Video leaves preview.
State these as unknown rather than guessing. Re-check the platform file's URLs when `last_verified` is older than 90 days.

## 10. Never claim
- That a label lowers reach on Meta or TikTok.
- That Muse is available in Facebook or Messenger, or that Muse Video is generally available.
- That an image is "clean" of AI provenance because a scan found nothing.
- That baby imagery is a policy problem for a baby-clothing brand.
