# Scoring: anchors, weights, math, verdicts

## Score anchors (1-10, every persona)

| Score | Meaning |
|---|---|
| 1-2 | Actively harmful: suppressed, labelled, mocked or removed |
| 3-4 | Below the platform's typical post; dies in the first test batch |
| 5 | Median post; dies quietly |
| 6 | Slightly above median; one clear weakness |
| 7 | Above average for this account; worth posting |
| 8 | Strong; needs a named comparable post or a cited mechanism |
| 9-10 | Top 1% of the niche; needs evidence from live search |

Rules: score against the platform's typical post, never against effort. A score of 8 or more with no comparable and no mechanism is capped at 7. With no web search, the Radar is capped at 6. Scores are never converted into views, reach or engagement numbers.

## Weight matrix

Persona weights per platform. This is editorial judgement `[INFERRED]` from each platform's stated or reported top signals, never a platform's own weights. Every row sums to 100.

| Platform | Ranker | Thumb | Radar | Crowd | Why |
|---|---|---|---|---|---|
| TikTok | 25 | 30 | 20 | 25 | Completion and rewatch start with the hook |
| Instagram Reels | 25 | 30 | 15 | 30 | Watch time, sends per reach |
| Instagram Feed | 30 | 25 | 10 | 35 | Likes per reach, saves, carousel dwell |
| YouTube Shorts | 30 | 30 | 15 | 25 | Viewed vs swiped away, view duration |
| X | 35 | 20 | 25 | 20 | Open-source weighted scorer, news cycle |
| LinkedIn | 30 | 15 | 20 | 35 | Dwell, comments, expertise |
| Facebook | 30 | 20 | 15 | 35 | Meaningful interactions, shares to people |
| Threads | 25 | 15 | 20 | 40 | Replies and conversation |
| Pinterest | 30 | 25 | 30 | 15 | Search and keyword intent, saves |
| Bluesky | 25 | 15 | 30 | 30 | Custom feeds and topics, community |

## Math

1. **Raw score** = (Ranker x wR + Thumb x wT + Radar x wRa + Crowd x wC) / 100.
2. **Bouncer multiplier** from the Bouncer's own score:

   | Bouncer score | Multiplier |
   |---|---|
   | 8.0-10 | x1.0 |
   | 6.0-7.9 | x0.9 |
   | 4.0-5.9 | x0.75 |
   | below 4.0 | x0.5 |

3. **Brain Score** = raw score x multiplier, rounded to one decimal.
4. **Veto:** a Bouncer kill flag means the post is never POST as it stands. The Bouncer states whether a fix exists. If none does, the verdict is KILL for this version.

## Verdicts

| Verdict | Rule |
|---|---|
| POST | Brain Score 7.0 or higher and no veto |
| FIX-THEN-POST | 5.0-6.9, or a veto with a fix when Brain Score is 5.0 or higher |
| KILL | Below 5.0 (a veto does not rescue it), or a veto with no fix |

If scored platforms disagree, give a verdict per platform and name the best one. Never average verdicts across platforms.

## Worked example (TikTok)

Ranker 6, Thumb 8, Radar 5, Crowd 6, Bouncer 6.

- Raw = (25x6 + 30x8 + 20x5 + 25x6) / 100 = (150 + 240 + 100 + 150) / 100 = 6.4
- Bouncer 6 gives x0.9, so Brain Score = 6.4 x 0.9 = 5.76, shown as **5.8**
- No veto, 5.8 falls in 5.0-6.9, so the verdict is **FIX-THEN-POST**

## Tie-breaks and checks

- A fix list that would move the Brain Score across a verdict line must say which fix does it.
- For A/B Battle, rank variants by Brain Score on the same platform with the same weights; a gap under 0.5 is "too close to call" and the tie goes to the lower Bouncer risk.
- Re-score only after a real change to the asset or caption, never to reach a number.
- Confidence tags: `[CODE]`, `[OFFICIAL]`, `[REPORTED]`, `[INFERRED]`. A report with no tags fails the integrity check.
