# Distribution playbook

last_verified: 2026-11-25
Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

Use this for the "Rewrites", "First-hour plan" and "Best platform and window" sections of the report. Hard platform numbers (limits, ratios, safe zones) live in `platforms/<name>.md`; this file holds the method.

## Contents
1. First-hour plan
2. Comment seeding
3. Cross-posting
4. Links
5. Hashtags and keywords (the Radar's method)
6. Posting time
7. Baby and kids product brands
8. Images carry no text

## 1. First-hour plan
Early engagement feeds the ranking pools on most platforms, but no platform publishes an exact window, so call it a habit, not a rule. [INFERRED]
- **Minute 0-5:** post natively (upload to the platform itself, no other app's watermark). Check the first frame, caption cut-off and alt text in the live post. Add the link where section 4 says.
- **Minute 5-30:** reply to every real comment with a specific answer, not "thanks". On X, Threads and Bluesky a reply that starts a thread is a ranked signal. [CODE for X; REPORTED for Threads] Send the post to the 2-3 people the Crowd named as the likeliest recipients (a direct send, not a mass tag).
- **Minute 30-60:** note what happened (saves, sends, comments, watch time where shown). Do not delete and repost a quiet post; that resets everything and can read as spam. Keep the numbers for a Post-mortem.

## 2. Comment seeding
- Seed one genuine question that has a real answer, in the caption or as the first comment. A question that names a person ("Who in your family still keeps every tiny sock?") invites a reply without begging for one.
- Never write engagement bait ("comment YES", "tag 3 friends"). Meta demotes it. [OFFICIAL] transparency.meta.com engagement-bait guideline
- Never ask staff, pods or bots to comment. LinkedIn acts against pods and automated comments. [OFFICIAL] news.linkedin.com, 2026-03-13

## 3. Cross-posting
- One idea, re-cut per platform: re-crop to the native ratio (use `scripts/crop_preview.py`), rewrite the hook and caption, swap hashtags for that platform's norm.
- Remove other apps' watermarks. Meta treats reused content as unoriginal, and Instagram stops recommending accounts that mostly repost. [OFFICIAL] creators.instagram.com, 2026-04-30
- Do not post the identical caption everywhere; platforms read near-duplicates as low-effort. [REPORTED]
- Stagger by a few hours, not seconds, so you can learn from the first platform.

## 4. Links
- X: the open-source code shows no link penalty [CODE]; executives deny one [REPORTED]. Facebook, Threads and LinkedIn: a link penalty is widely reported but not documented, so treat it as a possible reach cost. [REPORTED]
- Safe default: put the link in the first reply or a native link field, and make the post work without clicking.
- Pinterest and YouTube Shorts treat links differently; follow each platform file.
- For a shop, send traffic to one link per post, and say what the person gets when they click.

## 5. Hashtags and keywords (the Radar's method)
Never reuse an old hashtag block. Find live terms each run:
1. Web search `<product or topic> site:tiktok.com` and `<topic> pinterest` for what is being posted this month.
2. Check the platform's own suggestions: TikTok search autocomplete, Pinterest search suggestions and Trends, YouTube search autocomplete. Say which were checked and which could not be.
3. Keep 3-5 terms that describe the picture truthfully; follow each platform file's norm for count and placement (Instagram and Threads cap tags; Pinterest wants keywords in the title and description).
4. If search is unavailable, say so, give generic descriptive keywords, and cap the Radar score at 6.

## 6. Posting time
Weak evidence. The account's own analytics win; if none exist, use these as tiebreakers only, in the audience's local time.
- Sprout Social (2026-03-31): Facebook Mon 12-1pm and Tue-Wed 12-8pm; Instagram Tue 1-7pm, Wed 12-9pm; TikTok Wed 1-8pm; LinkedIn Tue-Thu 11am-5pm; X Tue-Thu 12-6pm; Pinterest Tue-Thu mornings; weekends weakest. [REPORTED]
- Buffer (2026): Threads Thu 9am; YouTube Shorts Fri 4-7pm; Bluesky Sat 5-6pm; LinkedIn Wed 4pm; TikTok Sun 9am. [REPORTED]
- YouTube's Shorts lead said in 2023 that time of day does not matter for Shorts except for news. A vidIQ analysis found upload hour made little difference. [REPORTED]
- The studies disagree with each other (TikTok Wed vs Sun). Say so rather than picking one as truth.

## 7. Baby and kids product brands
- AI babies showing the product are normal for the brand. Never a flag.
- Check every product post against the real garment: colour, cut, closures, print. A mismatch is a misleading-claim risk.
- Keep the presentation ordinary and safe: awake and comfortable, no unsafe sleep staging, no health or developmental claims in the caption.
- Label realistic AI people on the platforms that offer a label, and say in one line that the brand uses AI product models.

## 8. Images carry no text
- No headlines, captions, stickers or arrows on the picture. Words go in the caption's first line, the alt text, the title field or the spoken script.
- Allowed: text that is part of the product (a print, a tag, packaging), if every letter is correct.
- If a platform's native format normally uses overlay text (a carousel cover, a Pin), keep the picture clean and put the keyword in the Pin title, the first caption line or the document title field.
