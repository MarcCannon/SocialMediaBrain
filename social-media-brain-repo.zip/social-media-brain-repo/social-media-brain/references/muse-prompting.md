# Muse regeneration prompts

Turn each visual fix from the report into a prompt the user can paste into Muse (Meta AI app, meta.ai, Instagram Stories where available). Facts about what Muse can do live in `ai-content-and-muse.md`; re-check them if the asset came from Muse Video (preview) or from Facebook or Messenger (not confirmed available).

## Principles
- One fix per prompt. Changing five things at once changes the subject too.
- Say what to keep before what to change: subject, framing, palette, style.
- Name the target ratio and the UI safe zones from the platform file, and keep the key subject and any text inside them.
- Text: never in the image, except text that is part of the product (a print on a garment, a tag). Generators garble rendered text, so for product text check every letter against the real product, or ask for the print to be left blank and use the real product photo for close-ups. Words go in the caption, never on the picture.
- Babies and children: asking Muse for a baby or toddler wearing the product is normal. Keep them comfortable, ordinary and safe (awake and happy, or a calm natural pose; no unsafe sleep staging), and describe the garment precisely.
- Never prompt with a real person's name, a real person's account, or a brand's logo. Using an Instagram account as input is a likeness risk and a Bouncer veto unless the person consented.
- Never ask the generator to remove an AI label or watermark.
- Ask for one clear focal point and a plain background: it crops better and hides fewer artifacts.

## Template
```
Keep: <subject, setting, palette, style from the original>
Change: <the one fix>
Framing: <ratio, e.g. 9:16>, subject centred inside the safe zone
Text: none in the image (product print only, if any)
Avoid: <artifact seen: extra fingers, warped letters, duplicated background objects, over-smooth skin>
```

## Examples
**1. Hook unreadable at phone size (Thumb)**
```
Keep: the same product on a wooden table, warm morning light, same colour palette
Change: make the product larger and closer to the camera so it fills about 60 percent of the frame
Framing: 9:16, product in the middle third, clear of the top and bottom UI zones
Text: none in the image
Avoid: busy background, extra objects on the table
```

**1b. Baby clothing: garment must match the real product (Bouncer, Thumb)**
```
Keep: a happy baby sitting on a plain cream blanket, soft window light, same pose
Change: dress the baby in a sage-green ribbed short-sleeve bodysuit with a round neck and three snap buttons at the crotch, fabric visibly soft and matte, no pattern
Framing: 4:5, baby centred, whole bodysuit visible, nothing covering the garment
Text: none in the image
Avoid: extra fingers, merged hands and fabric, extra buttons, a different colour from the real product, any printed words or logos
```
Swap in the real product's colour, cut, trim and print before generating. If the product has a printed slogan, keep it only if every letter renders correctly.

**2. Garbled text / artifact (Bouncer)**
```
Keep: the same street scene, same time of day and style
Change: remove the shop sign and the posters so no readable text appears anywhere
Framing: 4:5, subject left of centre
Text: none in the image
Avoid: signs, labels, logos, any lettering
```

**3. Crop cuts the subject (Thumb, Ranker)**
```
Keep: the same character, outfit and pose, same illustration style
Change: pull the camera back so the full figure and a margin around it fit
Framing: 1:1 and also check it crops to 3:4 for the profile grid; subject in the centre 70 percent
Text: none in the image
Avoid: elements touching the frame edges
```

## After regeneration
Re-run the provenance scan and the Bouncer checklist on the new asset. Re-score only after a real change to the asset or caption, never to reach a number.
