# TikTok - ranking brief
last_verified: 2026-11-25
disclosure: low - TikTok publishes the pipeline steps, signal categories and eligibility rules but no order or weights; ByteDance's Monolith paper and code describe infrastructure, not TikTok's live model
scoring rows: TikTok  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages
1. Moderation first: only videos that pass initial moderation and are eligible for recommendation enter the pool. Videos just uploaded or still under review may be ineligible for anyone's For You feed (FYF). [OFFICIAL] TikTok Transparency Center, recommendation system page (c) 2025; TikTok newsroom 2020-06-18
2. Select: a large candidate pool is retrieved for the viewer. [OFFICIAL] Transparency Center (c) 2025
3. Predict: models estimate the chance of actions such as like, share, comment, skip, finish, favorite, follow, profile visit, tapping the sound, Not Interested, and viewing for a certain time. [OFFICIAL] Transparency Center (c) 2025
4. Rank: prediction scores are combined into one score and sorted, highest first. No weights are given. [OFFICIAL] Transparency Center (c) 2025
5. Similarity check: top videos too similar to their neighbours (for example, the same sound) are swapped out; the feed generally avoids two in a row with the same sound or creator. [OFFICIAL] Transparency Center (c) 2025; newsroom 2020-06-18
6. Recommendation rules at several points: broad-audience suitability, under-16 creators ineligible, mature content for 18+ only, and regional creator mix. [OFFICIAL] Transparency Center (c) 2025
7. Deliberate diversity: the system sometimes shows videos outside stated interests or with fewer likes. [OFFICIAL] newsroom 2020-06-18
8. "New uploads are tested on a small audience first" appears widely in creator guides but in neither official page read; unverified. [REPORTED]
9. Infrastructure: ByteDance's Monolith describes real-time online training with a collisionless embedding table, built for BytePlus Recommend; that TikTok runs it in production is not stated. [OFFICIAL] arXiv 2209.07663, 2022-09; [CODE] github.com/bytedance/monolith (archived 2025-10-13); [INFERRED]
10. US: the TikTok USDS joint venture said it will retrain the recommendation algorithm on US user data inside Oracle's cloud, with no timeline. Completion had not been confirmed as of 2026-05. [OFFICIAL] TikTok newsroom 2026-01-23; [REPORTED] CNBC 2026-02-16, Sen. Markey letter 2026-05-29

## Top signals (ranked)
TikTok gives no ranking order. The order below is [INFERRED] from the 2020 weight statements (finishing a longer video is a strong signal; settings are weak) and the 2025 predicted-interaction list.

| # | Signal | What it means for a post | Tag | Source + date |
|---|--------|--------------------------|-----|---------------|
| 1 | Finishing the video, especially a longer one | Named as a strong indicator of interest; a hook-to-payoff structure that keeps viewers to the end wins | [OFFICIAL] | Newsroom 2020-06-18; Transparency (c) 2025 |
| 2 | Time spent viewing | A predicted interaction; length is also a video signal, so pacing must justify the runtime | [OFFICIAL] | Transparency (c) 2025 |
| 3 | Skip | Predicted directly; a slow open is punished | [OFFICIAL] | Transparency (c) 2025 |
| 4 | Shares | Predicted interaction and a "signal from you" | [OFFICIAL] | Transparency (c) 2025; newsroom 2020-06-18 |
| 5 | Likes | Predicted interaction | [OFFICIAL] | Transparency (c) 2025 |
| 6 | Comments | Predicted interaction; comments posted are a user-interaction signal | [OFFICIAL] | Transparency (c) 2025; newsroom 2020-06-18 |
| 7 | Favorites (saves) | Predicted interaction | [OFFICIAL] | Transparency (c) 2025 |
| 8 | Follow or profile visit | Predicted interaction; follow relationships are a personalization factor | [OFFICIAL] | Transparency (c) 2025 |
| 9 | Sound tap and soundtrack | Tapping the soundtrack is predicted; the soundtrack is a video signal and drives the similarity check | [OFFICIAL] | Transparency (c) 2025 |
| 10 | Captions, hashtags, time and region posted | Video information signals used to match the video to viewers | [OFFICIAL] | Newsroom 2020-06-18; Transparency (c) 2025 |
| 11 | Others' behaviour | How viewers with similar histories engaged (collaborative signal) | [OFFICIAL] | Transparency (c) 2025 |
| 12 | Device, language, country | Lower weight than active signals; shared viewer-creator country is weak | [OFFICIAL] | Newsroom 2020-06-18 |

Not a direct factor: follower count and an account's past hit videos, though bigger accounts tend to get more views. [OFFICIAL] newsroom 2020-06-18

## Negative signals and penalties
- FYF ineligibility: content can stay up but be kept out of For You. Named categories include unoriginal or reused content, engagement manipulation and moderate misinformation, among others. Analytics shows creators when a video is ineligible. [OFFICIAL] TikTok Community Guidelines, FYF standards, released 2026-08-25, effective 2026-09-24
- Duplicated content, already-seen content and spam are not recommended. [OFFICIAL] newsroom 2020-06-18
- Not broad-audience suitable, or made by an account under 16: ineligible. [OFFICIAL] Transparency (c) 2025
- Unlabeled realistic AI-generated content (AIGC) may be removed, restricted or labeled by TikTok. [OFFICIAL] Integrity and authenticity guidelines, 2026-08-25, effective 2026-09-24
- Harmful or misleading AIGC is not allowed even if it is labeled. [OFFICIAL] Integrity and authenticity guidelines, 2026-08-25
- Similarity check: repeating a sound or format the viewer just saw gets swapped out. [OFFICIAL] Transparency (c) 2025
- Viewer controls: Not interested reduces similar content; keyword and hashtag filters remove matches; Report goes to moderation and does not directly change the feed. [OFFICIAL] Transparency (c) 2025
- Another platform's watermark: not named as a penalty in the sources read; reposted content falls under the unoriginal rule. [INFERRED]
- AIGC preference: viewers can turn down AIGC in Manage Topics, so heavy AI content may reach fewer of those viewers. [OFFICIAL] newsroom 2025-11-19; [INFERRED]

## Format specs and safe zones
| Format | Ratios | Length limits | Caption limit / "more" cut-off | Hashtag norms | Alt text |
|--------|--------|---------------|--------------------------------|---------------|----------|
| In-feed video (organic) | 9:16, 1080x1920 [REPORTED] | 10 min in-app is the widely reported standard; 60-min uploads tested 2024 [REPORTED, TechCrunch 2024-05-16] | 4,000 chars in-app [REPORTED]; 2,200 via API and schedulers [REPORTED]; "more" cut-off unverified | Count toward caption; no official cap found [REPORTED] | Not verified |
| Photo mode | Unverified | 2-35 photos [REPORTED] | As video [REPORTED] | As video | Not verified |
| In-feed ad (non-Spark) | 9:16 recommended at 540x960 or more; 1:1 and 16:9 also accepted | Up to 10 min; 500 MB; 516 kbps or higher | Ad text per Ads Manager | n/a | n/a |
| Spark ad (boosted organic) | As organic | No duration limit | As organic | As organic | n/a |

Ad rows: [OFFICIAL] TikTok Ads help, video ads specifications, updated 2026-06.

Safe zones (1080x1920 vertical)
- TikTok's ad spec says the safe zone depends on ratio, caption length and ad format, and links downloadable templates (In-Feed Standard, Anchor, Arabic), with no numbers on the page. [OFFICIAL] TikTok Ads help, 2026-06
- Measured from the official In-Feed Standard LTR template: top 240 px, bottom 660 px, left 120 px, right 120 px, plus a 180 px wide icon column on the right up to 1080 px from the bottom. [REPORTED] manypixels.co, 2026-11-11 (template scaled from 720x1280 by 1.5)
- Other third-party guides use a bottom 480 px and right 140 px; the template-based numbers are stricter and the safer default. [REPORTED] / [INFERRED]
- Organic posts have no official safe-zone numbers; long captions push the text block higher, so the bottom margin grows with caption length. [OFFICIAL] ads help 2026-06; [INFERRED]

## Native formats the platform pushes
- Longer videos that are finished: completion of longer videos is the strongest named signal, and 60-minute uploads were tested. [OFFICIAL] newsroom 2020-06-18; [REPORTED] TechCrunch 2024-05-16
- Photo mode carousels, up to 35 images. [REPORTED]
- Sound-led formats: the soundtrack is a video signal and sound taps are predicted. [OFFICIAL] Transparency (c) 2025
- TikTok's own AI effects are auto-labeled. [OFFICIAL] newsroom 2024-05-09
- Search: no official TikTok document on search ranking was found. Creator guides say captions, on-screen text, spoken words, hashtags and comments are indexed; unverified. [REPORTED]
- Creator Rewards needing videos over 1 minute is widely reported; not checked against a primary source this pass. [REPORTED, unverified]

## AI-generated content: labels, rules, consequences
- Creators must label realistic AIGC using the AIGC label (reaffirmed 2024-05-09 and in the 2026 guidelines). [OFFICIAL] newsroom 2024-05-09; Integrity and authenticity guidelines 2026-08-25
- Auto-label: TikTok reads C2PA Content Credentials and labels AIGC made on other platforms, starting with images and video (audio later); TikTok AI effects are labeled automatically. TikTok says not all AIGC will be caught. [OFFICIAL] newsroom 2024-05-09
- Invisible watermark test on TikTok-made AIGC and C2PA-tagged uploads, plus an AIGC slider in Manage Topics so viewers can see less AI. TikTok says it has labeled more than 1.3B videos. [OFFICIAL] newsroom 2025-11-19
- The slider can lower but not remove AI content; launch was described as a test and rollout over the coming weeks. No 2026 update found. [REPORTED] TechCrunch 2025-11-18
- Reach: TikTok Creator Academy material is reported to say the AIGC label does not affect reach if the video is otherwise eligible. The support page could not be read directly. [REPORTED]
- Non-disclosure: unlabeled realistic AIGC can be removed, restricted or labeled by TikTok; harmful or misleading AIGC is barred even if labeled. [OFFICIAL] guidelines 2026-08-25, effective 2026-09-24
- Muse output on TikTok: Muse Image carries Meta's Content Seal, which is not C2PA, and Meta has not said Muse writes C2PA. TikTok's auto-label may therefore not fire, so the creator must self-label realistic Muse content. [OFFICIAL] ai.meta.com 2026-07-07; [REPORTED] Engadget 2026-07-07; [INFERRED]
- Likeness of real people: the detailed rules in the 2026 guidelines were not re-read clause by clause; treat any realistic depiction of a real person as high-risk. [INFERRED]

## Ranker's predict-checklist
1. Does it hook in the first second, so skips stay low? [Signal 3]
2. Will most viewers reach the end, and does the length earn itself? [Signals 1, 2]
3. Is there a reason to share or favorite it (useful, funny, relatable)? [Signals 4, 7]
4. Will it draw comments without bait or engagement manipulation? [Signal 6; Negatives]
5. Is the sound fitting and distinct, not identical to a just-seen trend clip? [Signal 9; similarity check]
6. Do the caption and hashtags clearly say what the video is about? [Signal 10]
7. Is it original, not a repost or reuse? [Negatives: FYF ineligible]
8. Is it suitable for a broad audience? [Distribution stage 6]
9. Are text and faces inside 240 px top, 660 px bottom, 120 px sides, and clear of the right icon column? [Safe zones]
10. If it is realistic AIGC, is the AIGC label on? [AI section]
11. Does it avoid harmful or misleading AI, such as fake real-person scenes? [AI section]
12. Would a viewer who turned down AI in Manage Topics still be a target? If not, expect a narrower audience. [AI section]

## Primary URLs to re-check
- https://www.tiktok.com/transparency/en-us/recommendation-system/ - pipeline, signals, controls (read 2026-11-25)
- https://newsroom.tiktok.com/en-us/how-tiktok-recommends-videos-for-you - signal weights, diversity, 2020 (read 2026-11-25)
- https://www.tiktok.com/community-guidelines/en/fyf-standards - FYF eligibility (read 2026-11-25)
- https://www.tiktok.com/community-guidelines/en/integrity-authenticity - AIGC rules (read 2026-11-25)
- https://newsroom.tiktok.com/more-ways-to-spot-shape-and-understand-ai-content?lang=en - AIGC slider, watermark (read 2026-11-25)
- https://ads.tiktok.com/help/article/video-ads-specifications?lang=en - ad specs, safe-zone templates (read 2026-11-25)
- https://newsroom.tiktok.com/announcement-from-the-new-tiktok-usds-joint-venture-llc?lang=en - US retraining (read 2026-11-25)
- https://arxiv.org/abs/2209.07663 - Monolith paper (read 2026-11-25)
- https://github.com/bytedance/monolith - Monolith code, archived (read 2026-11-25)
- https://support.tiktok.com/en/using-tiktok/creating-videos/ai-generated-content - AIGC help (JS-only, not readable; retry in a browser)
