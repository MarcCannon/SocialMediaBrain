# Pinterest - ranking brief
last_verified: 2026-11-25
disclosure: high - many Pinterest papers and engineering posts lay out the models, the action heads and the blending rules, but the utility weights and live thresholds are not published
scoring rows: Pinterest  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages
1. Understanding the Pin. Search builds a text profile for each Pin from its title, description, board titles, the linked page's title and description, synthetic image captions, and the search terms that already engage with it. [OFFICIAL] (arXiv 2410.17152, 2024-10-22) Images are also embedded with a vision-language model, PinCLIP. [OFFICIAL] (arXiv 2603.03544, 2026)
2. Retrieval. Homefeed, Search and Related Pins each pull candidates using graph embeddings and user embeddings. PinSage and GraphSage are built on the graph of Pins and boards, and PinnerFormer predicts a user's long-term engagement. [OFFICIAL] (PinSage arXiv 1806.01973, 2018-06-06; PinnerFormer arXiv 2205.04507, 2022-05-09) Generative retrieval, PinRec, is a newer layer. [OFFICIAL] (arXiv 2504.10507, 2025)
3. Ranking. The Pinnability multi-task model predicts what a user will do with each Pin, such as click, save (repin) or hide, and then adds those predictions into one utility score. The weights are not published. [OFFICIAL] (TransAct, arXiv 2306.00248, 2023-05-31) The PinFM foundation model adds a share head. [OFFICIAL] (arXiv 2507.12704, v3 2025-08-20)
4. Personal weights. Since 2026, reinforcement learning tunes each user's mix of utility weights on Homefeed. [OFFICIAL] (PRL-PUTS, arXiv 2605.16344, 2026-05-08)
5. Blending. A diversity layer re-orders the ranked list. It used DPP from 2021 and SSD from early 2025. It measures how similar Pins are with PinCLIP, text and GraphSage embeddings, penalizes near-identical items through Semantic IDs (Q4 2025), and has spread out sensitive content since about Q2 2025. [OFFICIAL] (Pinterest Engineering, 2026-04-07, read through a secondary summary)
6. Search order. A five-level relevance model is combined with engagement predictions to set the final order of results. [OFFICIAL] (arXiv 2410.17152, 2024-10-22)
7. Long life. Saves predict later revisits, and Pinterest now optimizes Related Pins for that link between saving and coming back. [OFFICIAL] (arXiv 2511.18013, 2025-11-22) Because Pins keep resurfacing through search and Related Pins, a good Pin can earn traffic for months. [INFERRED]

## Top signals (ranked)
| # | Signal | What it means for a post | Tag | Source + date |
|---|---|---|---|---|
| 1 | Save (repin) | Saves are the main positive head the papers name, and they predict revisits. A Pin worth keeping beats a Pin that is merely pretty. | OFFICIAL | TransAct 2023-05-31; PinFM 2025-08-20; arXiv 2511.18013 2025-11-22 |
| 2 | Hide | A strong negative head. TransAct's launch cut hides by 10% online. Bait, clutter or offensive images get hidden. | OFFICIAL | TransAct 2023-05-31 |
| 3 | Click and outbound click | A click head exists, and long-clicks (dwell on the linked page) were modeled as well. The landing page has to deliver what the Pin promises. | OFFICIAL | TransAct 2023-05-31; Pinterest Engineering MTL post 2020-04-24 |
| 4 | Closeup | Opening a Pin was a separate head in the utility model. The image should reward a closer look. | OFFICIAL | Pinterest Engineering MTL post 2020-04-24 |
| 5 | Share | Share is a head in PinFM. | OFFICIAL | PinFM 2025-08-20 |
| 6 | Text relevance to search terms | Title, description, board title and link metadata all feed search relevance. Plain, keyword-rich wording wins over clever wording. | OFFICIAL | arXiv 2410.17152 2024-10-22 |
| 7 | Visual and semantic match | Image embeddings (PinCLIP) place a Pin near visually similar Pins and users' tastes. A clear, single-subject image is easier to match. | OFFICIAL / INFERRED | arXiv 2603.03544 2026 |
| 8 | Fit with the user's action history | TransAct and TransAct V2 rank against a user's recent and lifelong actions. Niche-consistent Pins reach people who already engage with that niche. | OFFICIAL | arXiv 2306.00248 2023-05-31; arXiv 2506.02267 2025-06 |
| 9 | Board and graph context | Board titles feed a Pin's text, and the Pin-board graph drives retrieval. Saving to a well-named, on-topic board helps. | OFFICIAL / INFERRED | PinSage 2018-06-06; arXiv 2410.17152 |
| 10 | Freshness (new content) | PinFM has special cold-start handling for new items, and its launch lifted saves of fresh content by 5.70% online. No source states a ranking bonus for freshness. | OFFICIAL / INFERRED | PinFM 2025-08-20 |
| 11 | Variety against near-duplicates | Near-identical images get spaced apart in the feed. Re-uploading the same image with a new title adds little. | OFFICIAL / INFERRED | Pinterest Engineering 2026-04-07 |
| 12 | Long-term engagement quality | Pinterest optimizes for future engagement and "successful sessions", not just the next click. | OFFICIAL | PinnerFormer 2022-05-09; PRL-PUTS 2026-05-08 |

## Negative signals and penalties
- Hides train the model directly against a Pin and against similar Pins for that user. [OFFICIAL] (TransAct 2023-05-31)
- Near-duplicates are spread out by the Semantic ID penalty and the SSD diversity step, so a batch of near-identical AI variations competes against itself. [OFFICIAL] (Pinterest Engineering 2026-04-07); effect on batches [INFERRED]
- Sensitive content is softly spaced apart in Homefeed. [OFFICIAL] (Pinterest Engineering 2026-04-07)
- Users who opt in to "See fewer AI Pins" for a category get fewer GenAI Pins in it. [OFFICIAL] (Pinterest Newsroom 2025-10-16, updated 2025-12-12)
- In the feed, images taller than 2:3 may be cut off. [OFFICIAL] (product specs help page, undated)
- When the title and description don't match the image, search relevance falls. [OFFICIAL basis: arXiv 2410.17152; INFERRED effect]
- A clickbait Pin that lets people down on the landing page can be caught by long-click and dwell modeling. [OFFICIAL basis: MTL post 2020-04-24; INFERRED effect]
- Spam, misleading links and repetitive posting are covered by the community guidelines, which were not re-read this session. [REPORTED, unverified]

## Format specs and safe zones
| Format | Ratios | Length limits | Caption/title limit / cut-off | Hashtag norms | Alt text |
|---|---|---|---|---|---|
| Standard image Pin | 2:3 recommended (1000x1500). Taller may be cut off [OFFICIAL] | PNG or JPEG, up to 20 MB on desktop and 32 MB in the app [OFFICIAL] | Title 100 characters, of which the first 40 are likely shown (30 for double-byte). Description up to 800 characters [OFFICIAL] | No current official guidance. Keywords in plain text matter more [REPORTED, unverified] | Up to 500 characters, read by screen readers only [OFFICIAL] |
| Video Pin | 1:1, 2:3, 4:5 or 9:16. Must be narrower than 1:2 and taller than 1.91:1 [OFFICIAL] | 4 s to 15 min, 6-15 s recommended. MP4, MOV or M4V, up to 2 GB [OFFICIAL] | Title 100 / description 800, as for image Pins [OFFICIAL] | As above | Supported on video Pins [OFFICIAL] |
| Carousel | 1:1 or 2:3 [REPORTED] | 2-5 images [OFFICIAL] | Title 100 / description 800 [OFFICIAL] | As above | Not confirmed for carousels [REPORTED, unverified] |
| Collections (ads) | Hero plus secondary images [OFFICIAL] | 1 hero, 3-24 secondary [OFFICIAL] | As above | As above | Not confirmed [REPORTED, unverified] |

Safe zones (9:16 video Pin):
- No official organic safe-zone spec was found. [REPORTED, unverified]
- On mobile, the title, the creator name and the save button sit over the bottom of the video, so key text belongs in the middle of the frame. [INFERRED]
- Feed tiles crop toward 2:3, so a 9:16 video should still read as a clear 2:3 center crop. [INFERRED from the 2:3 cut-off rule, OFFICIAL]

## Native formats the platform pushes
- Standard image and video Pins are now the only organic Pin types. In 2023 Idea Pins were merged into standard Pins, multi-page Idea Pins became video, and links became allowed on all Pins. [REPORTED] (about 2023-05-11)
- Business best practices call for 2:3 creative, a logo on every ad, a clear CTA, and creative refreshed for seasonal moments. [OFFICIAL] (business.pinterest.com creative best practices, undated, about 2025)
- Pinterest Trends: browser only, with advertiser features needing a Business account. It covers up to 2 years of history. [OFFICIAL] (help page, undated)
  - Search trends with weekly, monthly and yearly change, plus saves-based "trends in the spotlight".
  - Shopping trends, moments, and audience trends (past 90 days, updated daily).
  - Editors' picks and prediction icons.
  - Volume is normalized 0-100, up to 4 keywords can be compared, and age and gender filters are available.
- Keyword SEO is grounded in the search paper. The fields that feed relevance are the title, description, board title, link metadata and image content. [OFFICIAL] (arXiv 2410.17152) Third-party guides add that board naming and posting consistency matter. [REPORTED]
- Fresh Pins vs re-pins: Pinterest has no primary definition. Tailwind and others describe a fresh Pin as an image or video Pinterest hasn't seen before, and say a new title alone doesn't count. [REPORTED] Papers do support new imagery doing better than recycled near-duplicates. [INFERRED]

## AI-generated content: labels, rules, consequences
- The label: image Pins detected as AI-generated or AI-modified show an "AI modified" label at the bottom left in closeup, worldwide. On ads, the label sits in the ellipsis menu. [OFFICIAL] (Newsroom 2025-04-30; help page gen-ai-labels, undated)
- Detection: IPTC metadata, Pinterest's own classifiers, and the Pin owner's own disclosure. [OFFICIAL] (Newsroom 2025-04-30; help page gen-ai-labels)
- Appeals: a creator can appeal a wrong label through support. [OFFICIAL] (help page gen-ai-labels)
- User controls: Settings > "Refine your recommendations" lets users see fewer AI Pins, category by category. The Pin's three-dot menu has a "see fewer" option. [OFFICIAL] (Newsroom 2025-10-16; help page see-fewer-ai-pins)
  - Categories: architecture, art, beauty, entertainment, children's, men's and women's fashion, health, home decor, sport, and food and drink.
  - Food and drink was added on 2025-12-12.
- Pinterest also said it would make labels more noticeable. [OFFICIAL] (Newsroom 2025-10-16)
- Effect on reach: no Pinterest source says the label alone lowers ranking. The documented effect is that opted-out users in those categories see fewer GenAI Pins, plus any hides or skips the label draws. [INFERRED]
- Muse or Meta AI images: whether Meta's IPTC or C2PA metadata survives export and upload is unverified. If it does, expect an automatic label. [REPORTED, unverified; INFERRED]
- Stripping metadata to dodge the label leaves classifier detection in place, and the label can still be applied. [INFERRED from the OFFICIAL detection methods]
- Likeness and manipulated media rules were not re-verified this session. [REPORTED, unverified]

## Ranker's predict-checklist
1. Would a user save this Pin to come back to it, as a recipe, plan, how-to or reference? (save, revisit)
2. Is there anything that would make a user hide it, such as bait, clutter, shock or a misleading promise? (hide)
3. Does the destination page deliver what the image promises? (click, long-click)
4. Does the image reward a closeup, with detail, steps or legible text? (closeup)
5. Does the title put a plain search phrase in its first 40 characters? (title cut-off, search relevance)
6. Does the description (800 characters or less) use the words people actually search for? (search relevance)
7. Is it 2:3 (or a safe video ratio) so it isn't cropped in the feed? (format)
8. Is the image new, not a near-copy of the account's recent Pins? (Semantic ID penalty, fresh Pin)
9. Is it going to an on-topic, clearly named board? (board context)
10. Is this a category where users can opt out of AI Pins, and is the AI look likely to draw a label? (GenAI controls)
11. Does it match a rising term or a seasonal moment in Pinterest Trends? (relevance, timing)
12. Does it have alt text that describes the image? (accessibility)

## Primary URLs to re-check
- https://arxiv.org/abs/2306.00248 - TransAct, Pinnability heads, hide (2023-05-31), read 2026-11-25
- https://arxiv.org/abs/2507.12704 - PinFM, save/click/share/hide, fresh items (v3 2025-08-20), read 2026-11-25
- https://arxiv.org/abs/2410.17152 - search relevance text fields (2024-10-22), read 2026-11-25
- https://arxiv.org/abs/2511.18013 - save, revisit, retain (2025-11-22), read 2026-11-25
- https://arxiv.org/abs/2605.16344 - RL utility weight tuning (2026-05-08), read 2026-11-25
- https://arxiv.org/abs/2205.04507 - PinnerFormer (2022-05-09), read 2026-11-25
- https://medium.com/pinterest-engineering/evolution-of-multi-objective-optimization-at-pinterest-home-feed-06657e33cd10 - blending, diversity, Semantic ID (2026-04-07; 403, read through secondary summary), read 2026-11-25
- https://newsroom.pinterest.com/news/introducing-gen-ai-labels - AI modified label (2025-04-30), read 2026-11-25
- https://newsroom.pinterest.com/news/pinterest-rolls-out-new-tools-to-give-users-more-control-over-gen-ai-content/ - see fewer AI Pins (2025-10-16, updated 2025-12-12), read 2026-11-25
- https://help.pinterest.com/en/article/gen-ai-labels - detection, appeals, read 2026-11-25
- https://help.pinterest.com/en/business/article/pinterest-product-specs - specs, read 2026-11-25
- https://help.pinterest.com/en/business/article/pinterest-trends - Trends tool, read 2026-11-25
- https://help.pinterest.com/en-gb/node/2461 - alt text, read 2026-11-25
