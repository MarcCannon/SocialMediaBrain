# Threads - ranking brief
last_verified: 2026-11-25
disclosure: medium - Meta's Threads feed system card lists the predictions and signal families; no weights, no candidate counts, and few 2026 executive statements
scoring rows: Threads  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages
1. Inventory: eligible posts from accounts the viewer follows plus recommended accounts they do not follow, including fediverse posts where enabled. [OFFICIAL] Meta Transparency Center, Threads feed system card, updated 2025-03-07
2. Integrity filtering: posts that break Community Guidelines are removed; borderline or non-recommendable content can be limited in recommendations. [OFFICIAL] Threads feed system card 2025-03-07; Meta recommendation guidelines
3. Predict: models estimate how likely the viewer is to like, reply, click the post, click the profile, scroll past, spend time viewing, and spend time on the post's permalink. [OFFICIAL] Threads feed system card 2025-03-07
4. Rank: predictions are combined into a relevance score and sorted. No weights or candidate counts are published; do not invent them. [OFFICIAL] system card 2025-03-07; [INFERRED]
5. Followed accounts got more weight in the For You feed after late-2024 changes, and a Following feed exists as a chronological option. [REPORTED] Social Media Today, Nov 2024, citing Mosseri
6. Viewer steering: Dear Algo lets a viewer ask the feed for more or less of a topic in a post; the change lasts 3 days. Launched in the US, NZ, Australia and the UK. [OFFICIAL] about.fb.com, 2026-02-11
7. Topic tags help route a post into topic feeds and search; one tag per post. [OFFICIAL] Threads API posts docs (tag rules); [INFERRED] for the routing effect

## Top signals (ranked)
The system card gives no order. Rows 1-7 are its predictions, ranked by [INFERRED] judgment of what drives a text-first feed; rows 8-11 are its listed input signals.

| # | Signal | What it means for a post | Tag | Source + date |
|---|--------|--------------------------|-----|---------------|
| 1 | Reply likelihood | Threads is conversation-first; posts that invite real replies travel | [OFFICIAL] | Threads feed card 2025-03-07 |
| 2 | Like likelihood | Core prediction; the like-to-impression ratio is also an input | [OFFICIAL] | Threads feed card 2025-03-07 |
| 3 | Time viewing | Dwell on the post in feed; dense, readable text helps | [OFFICIAL] | Threads feed card 2025-03-07 |
| 4 | Click into the post | Opening the thread; a strong opening line that promises more | [OFFICIAL] | Threads feed card 2025-03-07 |
| 5 | Time on permalink | Time spent in the opened thread and its replies | [OFFICIAL] | Threads feed card 2025-03-07 |
| 6 | Profile click | Curiosity about the author; a clear voice and niche | [OFFICIAL] | Threads feed card 2025-03-07 |
| 7 | Scroll past (negative) | Predicted directly; a weak first line loses the impression | [OFFICIAL] | Threads feed card 2025-03-07 |
| 8 | Engagement over time windows | Engagement is counted over windows from about an hour to 84 days; posts can keep earning | [OFFICIAL] | Threads feed card 2025-03-07 |
| 9 | Replies and likes on descendant posts | Activity in the reply chain feeds back into the parent's score | [OFFICIAL] | Threads feed card 2025-03-07 |
| 10 | Recency | Posts from the last week or month are named inputs | [OFFICIAL] | Threads feed card 2025-03-07 |
| 11 | Relationship with author | Follows and past interaction; followed accounts weighted up since late 2024 | [REPORTED] | Social Media Today, Nov 2024 (Mosseri) |

Not listed as predictions on the card: reposts, quotes and follows. They may still matter indirectly; treat them as unweighted. [OFFICIAL] card 2025-03-07; [INFERRED]

Mosseri (via secondary) has said the value of a reply is roughly equal to the value of a post for ranking. [REPORTED] Platformer, attributed to Mosseri, exact date not confirmed

## Negative signals and penalties
- Hide and Report: both reduce similar content for that viewer. [OFFICIAL] Threads feed card 2025-03-07
- Scroll past is a predicted negative. [OFFICIAL] card 2025-03-07
- Links are not penalized by ranking, but link posts tend to collect fewer likes and replies, so they can rank lower on engagement. [REPORTED] Mosseri Threads post Nov 2024 (threads.com/@mosseri/post/DCpQG0hz0m8), via Social Media Today
- Mosseri said in June 2025 that link posts were performing much better than before. [REPORTED] Mosseri post DKdzO8fumTq, via Social Media Today 2025-06-08
- More than 5 unique links in a post fails to publish via the API since 2025-12-22. [OFFICIAL] Threads API posts docs
- Non-recommendable content (Meta's shared recommendation guidelines) is limited in recommendations to non-followers. [OFFICIAL] Meta Transparency Center; [INFERRED] that the same rules apply on Threads
- Engagement bait and unoriginal reposts: no Threads-specific penalty found in sources read; the 2026-04-30 Instagram originality change was announced for Instagram only. [INFERRED]
- Watermarks from other apps: no Threads-specific statement found. [INFERRED]

## Format specs and safe zones
| Format | Ratios | Length limits | Caption limit / "more" cut-off | Hashtag norms | Alt text |
|--------|--------|---------------|--------------------------------|---------------|----------|
| Text post | n/a | 500 characters; emoji counted by UTF-8 bytes in API | 500; long posts truncate in feed (cut-off unverified) [REPORTED] | One topic tag, 1-50 chars, no periods or "&" | n/a |
| Text attachment | n/a | Up to 10,000 characters attached to a post | Post text still 500 | One topic tag | n/a |
| Link post | n/a | Links only with text-only posts in API; up to 5 unique links | 500 | One topic tag | n/a |
| Image | Up to 10:1; min width 320 px; JPEG or PNG, 8 MB | n/a | 500 | One topic tag | Supported in app [REPORTED]; API alt_text field unverified |
| Video | 0.01:1 to 10:1; 9:16 recommended; width up to 1920 px | Up to 300 s, 1 GB via API | 500 | One topic tag | Not verified |
| Carousel | Mixed image/video | 2-20 items | 500 | One topic tag | As image |

Spec sources: [OFFICIAL] Threads API posts docs (developers.facebook.com/docs/threads/posts/), read 2026-11-25; text attachments [OFFICIAL] about.fb.com 2025-09-04. API limits can differ from what the app allows. [INFERRED]
- API publishing cap: 250 posts per account per 24 hours. [OFFICIAL] Threads API docs
- Text attachments are reported as not indexed for search and not shared to the fediverse. [REPORTED] TechCrunch 2025-09-04

Safe zones
- Threads has no official safe-zone guidance; vertical video shows inside the feed card, not full screen by default. [INFERRED]
- When a video is opened full screen, the bottom area holds the author line and action buttons; keep key text away from the bottom edge. No source gives a number. [INFERRED]

## Native formats the platform pushes
- Text-first posts and conversation threads; the ranker predicts replies and permalink time. [OFFICIAL] card 2025-03-07
- Text attachments for long-form takes, launched 2025-09-04. [OFFICIAL] about.fb.com 2025-09-04
- Topic tags and topic communities. [OFFICIAL] API docs; [REPORTED] for community features
- Dear Algo public steering of the feed (2026-02-11). [OFFICIAL] about.fb.com 2026-02-11
- Threads reported 500M monthly active users in June 2026. [REPORTED]
- No 2026 Mosseri statement on Threads ranking weights was found. [REPORTED - searched, none found]

## AI-generated content: labels, rules, consequences
- Meta applies its "AI info" label across Facebook, Instagram and Threads when it detects industry signals (C2PA, IPTC) or the user self-discloses. [OFFICIAL] Meta Transparency Center, labeling AI content, updated 2025-02-19; about.fb.com 2024-02-06
- Since 2024-09-12, content only edited with AI tools shows the label in the post menu rather than on the post. [REPORTED] TechCrunch 2024-09-12
- Users must disclose photorealistic video and realistic audio made or altered with AI; Meta may apply penalties for failing to. [OFFICIAL] about.fb.com 2024-02-06
- Meta labeled content on Threads with 150M+ views and took 480K+ labeling actions in October 2024. [OFFICIAL] Meta Transparency Center labeling page (Oct 1-29 2024 data)
- API publishers can set `is_made_with_ai` on a post, which marks it as AI-made. [OFFICIAL] Threads API posts docs
- Reach effect of the label: no Meta source says the label itself changes ranking. [OFFICIAL - absence] / [INFERRED]
- AI-generated profile label (Instagram, 2026-08-31): undisclosed AI persona accounts lose recommendations on Instagram; whether this also applies on Threads is unverified. [OFFICIAL] creators.instagram.com 2026-08-31; [REPORTED - Threads scope unverified]
- Muse Image output carries Meta's Content Seal watermark, not C2PA; whether Threads auto-labels it is unverified, so self-disclose realistic Muse content. [OFFICIAL] ai.meta.com 2026-07-07; [INFERRED]

## Ranker's predict-checklist
1. Does the first line stop the scroll on its own? [Signal 7]
2. Does the post invite a real reply, not a bait request? [Signal 1; Negatives]
3. Is it likeable at a glance, with a high like-to-impression ratio likely? [Signal 2]
4. Is there a reason to open the thread or attachment? [Signals 4, 5]
5. Does it fit in 500 characters, or use a text attachment cleanly? [Specs]
6. Does it carry exactly one relevant topic tag? [Specs; Stage 7]
7. If it has a link, does the text still earn likes and replies alone? [Negatives: links]
8. Would the author's voice make a viewer tap the profile? [Signal 6]
9. Can it keep earning over days through replies in the chain? [Signals 8, 9]
10. Is any realistic AI image, video or audio disclosed or labeled? [AI section]
11. Is the content free of anything that would make it non-recommendable? [Negatives]

## Primary URLs to re-check
- https://transparency.meta.com/features/explaining-ranking/ig-threads-feed/ - Threads predictions and signals (read 2026-11-25; page updated 2025-03-07)
- https://developers.facebook.com/docs/threads/posts/ - character, link, tag, media and rate limits (read 2026-11-25)
- https://about.fb.com/news/2025/09/attach-text-threads-posts-share-longer-perspectives/ - text attachments (read 2026-11-25)
- https://about.fb.com/news/2026/02/threads-dear-algo/ - Dear Algo (read 2026-11-25)
- https://transparency.meta.com/governance/tracking-impact/labeling-ai-content - AI label data (read 2026-11-25)
- https://about.fb.com/news/2024/02/labeling-ai-generated-images-on-facebook-instagram-and-threads/ - AI label policy (read 2026-11-25)
- https://www.threads.com/@mosseri/post/DCpQG0hz0m8 - Mosseri on links, Nov 2024 (via secondary, 2026-11-25)
- https://www.threads.com/@mosseri/post/DKdzO8fumTq - Mosseri on links, Jun 2025 (via secondary, 2026-11-25)
- https://creators.instagram.com/blog/ai-generated-profile-label - AI profile label, check Threads scope (read 2026-11-25)
