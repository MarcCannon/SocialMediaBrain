# Bluesky - ranking brief
last_verified: 2026-11-25
disclosure: low - the Discover feed's ranking is not documented, while the protocol, the lexicons and the feed-generator template are open source, so custom-feed reach is transparent and Discover is not
scoring rows: Bluesky  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages
1. Publish. A post is written to the author's repository and streamed on the public firehose (com.atproto.sync.subscribeRepos), where any service can read it. [CODE] (github.com/bluesky-social/feed-generator README)
2. Following. Followers see the post in their Following feed. Following is commonly described as chronological. [REPORTED]
3. Discover. Discover is Bluesky's own algorithmic feed, and it mixes posts from accounts the viewer follows with posts from accounts they don't. Each post menu has "Show more like this" and "Show less like this". [REPORTED] (TechCrunch 2024-05-10, app v1.81) A private dislikes signal was announced as a beta to personalize Discover and other feeds. [OFFICIAL] (Bluesky blog 2025-10-31)
4. Custom feeds. Third-party feed generators index the firehose and return lists of post URIs through getFeedSkeleton, and the AppView then fills in the full posts. A feed can select any public post, whether or not the viewer follows the author. [CODE] (feed-generator README); reach to non-followers [INFERRED]
5. Trending topics are powered by custom feeds. Bluesky has said it is exploring topic tags and curation tools for timely event feeds. [OFFICIAL] (Bluesky blog "What's Next at Bluesky", 2026-01-26)
6. Threads. Replies are ranked by models that Bluesky was testing in late 2025. "Social neighborhoods" will rank replies from closer accounts higher, and a toxicity model down-ranks toxic, spammy, off-topic or bad-faith replies in threads, search and notifications. [OFFICIAL] (Bluesky blog 2025-10-31)
7. Social spread. Reposts and quote posts reach the reposter's followers, while starter packs and "who to follow" grow the graph. [INFERRED] (starter pack lexicon [CODE]; follow recommendations on the 2026-01-26 roadmap [OFFICIAL])

## Top signals (ranked)
| # | Signal | What it means for a post | Tag | Source + date |
|---|---|---|---|---|
| 1 | Custom feed selection rules | Each feed sets its own rules, such as keywords, hashtags, tags, language or author lists. A post reaches non-followers mainly by matching a popular feed's rules. | CODE / INFERRED | feed-generator README (read 2026-11-25) |
| 2 | Hashtags and post tags | Posts can carry up to 8 tags of 64 graphemes each, in addition to inline hashtags. Topic feeds often match on these. | CODE / INFERRED | app.bsky.feed.post lexicon (read 2026-11-25) |
| 3 | Show more / show less like this | Viewers' explicit feedback steers Discover. | REPORTED | TechCrunch 2024-05-10 |
| 4 | Dislikes (beta) | Dislikes are a private negative signal that personalizes Discover and lightly down-ranks low-quality replies. | OFFICIAL | Bluesky blog 2025-10-31 |
| 5 | Reply quality | Toxic, spammy, off-topic or bad-faith replies are down-ranked, so good conversation keeps a thread visible. | OFFICIAL | Bluesky blog 2025-10-31 |
| 6 | Social closeness | Replies from closer accounts are being prioritized through social neighborhoods. Community ties matter more than reach. | OFFICIAL | Bluesky blog 2025-10-31 |
| 7 | Likes, reposts, replies | These likely feed Discover and many custom feeds, but Bluesky has published no weights. | INFERRED | none published |
| 8 | Links | Bluesky says it does not de-promote posts with links. Since March 2025 links route through go.bsky.app for referral tracking. | REPORTED (of OFFICIAL) | NBC News, about 2024-11 (COO Rose Wang); go.bsky.app [REPORTED] |
| 9 | Authentic engagement | Artificially inflating engagement for reach you didn't earn is banned. | OFFICIAL | Community guidelines, updated 2025-09-19 |
| 10 | Labels from moderation services | Labelers that a viewer subscribes to can hide, blur or warn on a post. These labels come from moderation, separate from Discover ranking. | OFFICIAL / INFERRED | Community guidelines 2025-09-19 |
| 11 | Starter packs | Being listed in a starter pack brings follows, and so a Following audience. | CODE / INFERRED | app.bsky.graph.starterpack lexicon |

## Negative signals and penalties
- Dislikes and "show less like this" both push a post down Discover for that viewer. [OFFICIAL 2025-10-31; REPORTED 2024-05-10]
- The toxicity model down-ranks toxic, spammy, off-topic or bad-faith replies in threads, search and notifications. [OFFICIAL] (Bluesky blog 2025-10-31)
- Bluesky said in 2025 that it planned experiments on rage-bait. [OFFICIAL] (Bluesky blog 2025-09-19)
- The community guidelines took effect on 2025-10-15 and rest on four principles: Safety First, Respect Others, Be Authentic, and Follow the Rules. [OFFICIAL] (Bluesky blog 2025-09-19)
  - Banned: spam, impersonation, and inflating engagement for reach you didn't earn.
  - Parody and fan accounts must say so in both the display name and the bio.
  - Commercial content must be disclosed.
- Every image and video is reportedly sent to Hive for automated assessment. [REPORTED] (via search on the 2025 transparency report of 2026-01-29)
- Moderation and community labels can hide or warn on a post for the people who subscribe to that labeler. [OFFICIAL] (community guidelines, composable moderation)

## Format specs and safe zones
| Format | Ratios | Length limits | Caption/title limit / cut-off | Hashtag norms | Alt text |
|---|---|---|---|---|---|
| Text post | n/a | 300 graphemes (3,000 bytes) [CODE] | Same 300 graphemes [CODE] | Up to 8 tags of 64 graphemes each, plus inline hashtags [CODE]. Use 1-3 that match feed keywords [INFERRED] | n/a |
| Image post (images embed) | Any. Up to 4000x4000 px [REPORTED] | Up to 4 images, 2 MB each [CODE] | 300 graphemes [CODE] | As above | No lexicon limit [CODE]. App caps alt text at 2,000 characters [REPORTED] |
| Gallery post (gallery embed) | Any | Lexicon allows 20 images, clients enforce 10, 2 MB each [CODE]. Live since about 2026-06 [REPORTED] | 300 graphemes [CODE] | As above | As above |
| Video post | Any. Vertical is supported [REPORTED] | MP4, up to 300 MB [CODE]. Up to 10 min since 2026-08-26 [REPORTED] | 300 graphemes. Up to 20 VTT caption files [CODE] | As above | Video alt field, no lexicon limit [CODE] |
| Link card (external embed) | Card thumbnail | 1 card per post [CODE] | 300 graphemes [CODE] | As above | n/a |
| Starter pack | n/a | Name 50 graphemes, description 300 [CODE]. Up to 3 feeds [CODE]. Up to 150 people [REPORTED] | n/a | n/a | n/a |

Safe zones (vertical video):
- No official safe-zone spec was found. [REPORTED, unverified]
- Video plays inline in the feed with only light controls, so the overlay problem is smaller than on TikTok or Shorts. [INFERRED]
- Feeds can crop or letterbox a tall frame, so keep the subject centered. [INFERRED]

## Native formats the platform pushes
- Custom feeds: there are more than 100k of them. They also power trending topics. [OFFICIAL] (Bluesky blog 2025-09-19; 2026-01-26)
- Starter packs: a curated list of people plus up to 3 feeds, shared as one link. [CODE] (starterpack lexicon) The feature launched in mid-2024. [REPORTED] (TechCrunch 2024-06-27)
- Galleries of up to 10 images in a single post. The design was proposed in atproto Discussion #5032 on 2026-06-02. [OFFICIAL/CODE]; release about 2026-06 [REPORTED]
- Video of up to 10 minutes and 300 MB. [REPORTED] (GIGAZINE, Dataconomy 2026-08-27); 300 MB [CODE]
- The 2026-01-26 roadmap: [OFFICIAL] (Bluesky blog)
  - A dedicated Discover team, with no ranking details given.
  - A better "who to follow" and exploration of topic tags.
  - Real-time event feeds and a Live Now badge (Twitch or Streamplace).
  - Faster uploads and drafts. More than 4 photos was listed as a need, and galleries have since shipped.
- Profile Links were announced on 2026-10-22. Only the title was reviewed. [OFFICIAL, contents unverified]

## AI-generated content: labels, rules, consequences
- Bluesky has no general AI-label requirement. The community guidelines (updated 2025-09-19) say nothing about AI, deepfakes or manipulated media in general. [OFFICIAL]
- No Bluesky-applied AI label was found in Bluesky's docs or 2025-2026 blog posts. [REPORTED, unverified]
- Explicitly banned, including when AI-made:
  - Synthetic sexual content involving minors.
  - Synthetic sexual content involving animals.
  - Non-consensual intimate content, including digitally altered images.
  - [OFFICIAL] (community guidelines 2025-09-19)
- Likeness: impersonation is banned, and parody must be stated in both the display name and the bio. A synthetic likeness of a real person passed off as real falls under impersonation or deception. [OFFICIAL]; application to AI [INFERRED]
- Labels and ranking: independent labelers, which can include community AI-tagging labelers, apply labels that subscribing users can hide or warn on. This is composable moderation and separate from Discover ranking. [OFFICIAL basis; INFERRED split]
- Whether a label affects reach: no source says that labels change Discover ranking. [INFERRED]
- The audience: a vocal part of Bluesky's users are hostile to AI imagery. That makes dislikes, "show less", blocks and community labels the realistic reach risk for Muse content. [INFERRED]
- Disclosing AI use in the post text or alt text is not required by policy, but it lowers the risk of backlash. [INFERRED]

## Ranker's predict-checklist
1. Does the post match the keywords or hashtags of at least one active custom feed in its niche? (feed selection)
2. Does it use 1-3 relevant hashtags or tags rather than a block of them? (tags)
3. Does it fit in 300 graphemes and still make sense without opening the media? (format)
4. Does every image or video have descriptive alt text? (norms)
5. Is it written to start a real conversation rather than rage-bait? (reply ranking, toxicity, rage-bait tests)
6. Would a follower repost it to their own followers? (social spread)
7. If the visuals are AI-made, would this audience be likely to dislike, "show less", block or label it? (dislikes, labelers)
8. If it is parody or uses a real person's likeness, is that stated clearly? (impersonation rule)
9. Is it free of engagement bait, follow-for-follow and inflated metrics? (authenticity rule)
10. If it links out, is the link the payoff and not filler? (links are not de-promoted)
11. If it's a video, is it under 10 minutes and 300 MB with captions? (video spec)

## Primary URLs to re-check
- https://bsky.social/about/blog/01-26-2026-whats-next-at-bluesky - 2026 roadmap (2026-01-26), read 2026-11-25
- https://bsky.social/about/blog/10-31-2025-building-healthier-social-media-update - dislikes, reply ranking, toxicity (2025-10-31), read 2026-11-25
- https://bsky.social/about/blog/09-19-2025-building-healthier-social-media - guidelines, custom feed count (2025-09-19), read 2026-11-25
- https://bsky.social/about/support/community-guidelines - rules (updated 2025-09-19), read 2026-11-25
- https://bsky.social/about/blog/01-29-2026-transparency-report-2025 - moderation and Hive use (2026-01-29), read 2026-11-25
- https://github.com/bluesky-social/feed-generator - feed generator mechanics, read 2026-11-25
- https://github.com/bluesky-social/atproto/blob/main/packages/api/lexicons/app/bsky/feed/post.json - 300 graphemes, tags, read 2026-11-25
- https://github.com/bluesky-social/atproto/blob/main/packages/api/lexicons/app/bsky/embed/images.json - 4 images, 2 MB, read 2026-11-25
- https://github.com/bluesky-social/atproto/blob/main/packages/api/lexicons/app/bsky/embed/gallery.json - gallery 20 / client 10, read 2026-11-25
- https://github.com/bluesky-social/atproto/blob/main/packages/api/lexicons/app/bsky/embed/video.json - 300 MB, captions, read 2026-11-25
- https://github.com/bluesky-social/atproto/blob/main/packages/api/lexicons/app/bsky/graph/starterpack.json - starter pack limits, read 2026-11-25
- https://github.com/bluesky-social/atproto/discussions/5032 - gallery proposal (2026-06-02), read 2026-11-25
