# YouTube Shorts - ranking brief
last_verified: 2026-11-25
disclosure: medium - YouTube names its metrics and has said a lot on record about how ranking works, but has published no weights or thresholds for the Shorts recommender
scoring rows: YouTube Shorts  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages
1. Classification. A square or vertical upload of up to 3 minutes is treated as a Short. Official Artist Channels have been covered by this since 2025-12-08. [OFFICIAL] (help answer/15424877)
2. Separate system. Shorts, long-form and live each have their own recommendation system, and YouTube says it has seen no evidence that Shorts hurt a channel's long-form. [OFFICIAL] (YouTube blog, 2025-05-06)
3. Seed test. A new Short goes to a small seed audience first, and YouTube widens or narrows its reach based on how that audience responds. [REPORTED] (Todd Sherman, Shorts product lead, quoted by TechCrunch 2023-08-25)
4. Scale or taper. The audience's choice to watch or swipe away shows up in Studio as "Viewed vs swiped away", and retention shows up as average view duration and percentage viewed. [OFFICIAL] (help answer/12220281, undated)
5. Feed coherence. The feed groups videos of similar length together, and Sherman rates retention and "valued watch time" above likes. [REPORTED] (PPC Land 2025-01-29, from a Sherman talk of about 2025-01-28)
6. Long tail. A Short can be found later through search, hashtag pages, remix chains and the Related Video link. [OFFICIAL] (help answer/13748639) No source covers how search ranks Shorts in particular. [INFERRED]
7. Money. Shorts earn from ads shown between Shorts. Since 2026-08-24 a view counts from the first frame, while "engaged views" decide earnings and are the base for CTR, AVD and retention figures. YouTube says recommendations did not change with this switch. [OFFICIAL] (YouTube blog 2025-05-06; YouTube blog 2026-08-19)

## Top signals (ranked)
| # | Signal | What it means for a post | Tag | Source + date |
|---|---|---|---|---|
| 1 | Viewed vs swiped away | A Short has to stop the thumb at the first frame. Frequent early swipes cut off the seed test. | OFFICIAL (metric) / REPORTED (weight) | answer/12220281 (undated); Sherman via TechCrunch 2023-08-25 |
| 2 | Average view duration and percentage viewed | Retention is the strongest signal the company names. Pacing has to hold attention to the end. | OFFICIAL (metric) / REPORTED (emphasis) | answer/12220281; PPC Land 2025-01-29 |
| 3 | Valued watch time (satisfaction) | Being watched is not enough. The viewer should feel the time was well spent, and clickbait that lets the viewer down works against this. | REPORTED | PPC Land 2025-01-29 (Sherman) |
| 4 | Engaged views | Engaged views qualify a Short for earnings and are the base for retention and CTR in Studio. Raw views now count from the first frame. | OFFICIAL | YouTube blog 2026-08-19 |
| 5 | Replays and loops | Since 2025-03-31 every replay counts as a view. No source says loops raise ranking. | REPORTED (count) / INFERRED (ranking) | TechCrunch 2025-03-26 |
| 6 | Audience and topic fit | The seed audience is chosen to match the content, so a clear topic and clear opening context help the system find the right viewers. | REPORTED / INFERRED | Sherman via TechCrunch 2023-08-25 |
| 7 | Originality across the channel | Mass-produced, templated or reused content puts YPP status at risk and is judged channel-wide, not only Short by Short. | OFFICIAL | YPP policy answer/1311392 (inauthentic rename 2025-07-15) |
| 8 | Likes, comments, shares, subscribes | These are secondary to retention in what Sherman has said. Use them to break ties, not as the main score. | REPORTED | PPC Land 2025-01-29 |
| 9 | Audio | Trending sounds can help but are not required. | OFFICIAL | YouTube blog 2025-05-06 |
| 10 | Title, description, hashtags | These are mostly for search and discovery pages. Up to 3 hashtags are shown, and more than 60 means YouTube ignores all of them. | OFFICIAL (hashtags) / INFERRED (search) | answer/6390658 (undated) |
| 11 | Posting time | Time of day doesn't matter, except for news. | REPORTED | Sherman via TechCrunch 2023-08-25 |

## Negative signals and penalties
- A high early swipe-away rate stops a Short from reaching more viewers once the seed test ends. [OFFICIAL metric; INFERRED effect]
- Deleting a Short and reposting it can look like spam, and it does not reset performance. [REPORTED] (Sherman via TechCrunch 2023-08-25)
- On 2025-07-15 YouTube renamed "repetitious content" to "inauthentic content" in YPP. Examples include low-variation videos built on one template, the same characters and outcome every time, slideshows, scrolling text, and AI output on generic templates with no original view. A series with distinct stories is still allowed. [OFFICIAL] (answer/1311392)
- Rene Ritchie, YouTube's creator liaison, called the 2025 rename a minor clarification rather than a new crackdown. [REPORTED] (Search Engine Journal and Social Media Today, July 2025)
- YouTube judges reused content (other people's material without real transformation) across the whole channel. The YPP consequences are withheld earnings, suspension or termination. [OFFICIAL] (answer/1311392)
- More than 60 hashtags means all of them are ignored. Misleading or unrelated tags can get a video removed, and over-tagging can take it out of search. [OFFICIAL] (answer/6390658)
- A Short longer than 1 minute with an active Content ID claim is blocked worldwide. [OFFICIAL] (answer/15424877)
- Realistic synthetic content posted without disclosure can draw a label applied by YouTube, removal, or YPP suspension if it keeps happening. See the AI section below. [OFFICIAL] (answer/14328491)
- Watermarks or reposts from other apps: YouTube has issued no current statement on how these are treated. [REPORTED, unverified]

## Format specs and safe zones
| Format | Ratios | Length limits | Caption/title limit / cut-off | Hashtag norms | Alt text |
|---|---|---|---|---|---|
| Short (vertical) | 9:16, 1080x1920 recommended [REPORTED] | Up to 3 min since 2024-10-15 [OFFICIAL]. Up to 15 Shorts per Studio batch upload [OFFICIAL]. Audio Library allows up to 90 s of most songs [OFFICIAL] | Title 100 characters, description 5,000 [REPORTED]. The feed shows only the start of the title over the video [INFERRED] | 1-3 relevant tags. Over 60 means all are ignored [OFFICIAL]. Whether #shorts is still needed: no current official guidance [REPORTED, unverified] | No alt-text field. Use uploaded subtitles, never burned-in text [INFERRED] |
| Short (square) | 1:1 [OFFICIAL] | Up to 3 min [OFFICIAL] | Same as vertical | Same as vertical | Same as vertical |

Safe zones (1080x1920):
- No readable official spec was found. The Google PDFs could not be parsed. [REPORTED, unverified]
- Reported margins to keep text and faces clear of: top about 288 px, bottom about 672 px, left about 48 px, right about 192 px. [REPORTED] (Socialync, citing Google Ads help answer/9128498)
- The like, comment, share and remix buttons sit on the right edge. The channel name, title and description sit at the bottom left. [REPORTED]
- The title overlay covers the lower third of the frame, so keep the subject out of it. Subtitles go in the upload field, not burned in. [INFERRED]

## Native formats the platform pushes
- Shorts of up to 3 minutes, available since 2024-10-15. [OFFICIAL] (YouTube blog "Tall updates coming to Shorts", early Oct 2024)
- The Related Video link sends Shorts viewers to a long-form video or live stream. Path: Studio > Content > the Short > Related Video > Save. It needs advanced features, and the target must be public or unlisted. [OFFICIAL] (answer/14075157)
- Clickable items in Shorts: Related Video, @mentions, hashtags and remix attribution. URLs in Short descriptions and comments are not clickable, a change secondary sources date to 2023-08-31. [OFFICIAL] (answer/13748639); date [REPORTED]
- A brand link is available only for sponsored Shorts in a reported brand-deal campaign. It allows one link and is shown to mobile organic viewers. [OFFICIAL] (answer/16722303)
- Remixing (reusing another video's audio or clips) is native and credits the source. [OFFICIAL] (answer/13748639)
- YouTube's own generative tools (Veo, Dream Screen) are built into Shorts, and their output carries a permanent AI label. [OFFICIAL] (YouTube blog 2026-05-27)

## AI-generated content: labels, rules, consequences
- What must be disclosed: realistic content a viewer could take for real, such as a real person appearing to say or do something they didn't, altered footage of real events or places, realistic scenes that never happened, or AI music as the focus. [OFFICIAL] (answer/14328491)
- Exempt: clearly unrealistic content (animation, fantasy), minor edits such as filters, captions or upscaling, and help with ideas or scripts. [OFFICIAL] (answer/14328491)
- Where to disclose: YouTube Studio > upload flow > Attributes > "AI use" > Yes. The help page currently calls this "AI use"; it was formerly the "altered or synthetic content" setting. [OFFICIAL] (answer/14328491)
- Where the label appears: as an overlay on the Shorts player, or below the player on long-form, for photorealistic or meaningfully altered content. For unrealistic or lightly altered content it appears in the expanded description. [OFFICIAL] (YouTube blog 2026-05-27)
- Automatic labels: since May 2026 YouTube adds labels itself, based on detection, C2PA content credentials, or use of YouTube's own tools. A creator can fix a wrong label in Studio, but not a label from YouTube's tools, a fully generative C2PA source, or a manual review. [OFFICIAL] (YouTube blog 2026-05-27; answer/14328491)
- Effect on reach: YouTube says the label alone does not change recommendation or monetization eligibility. [OFFICIAL] (YouTube blog 2026-05-27; answer/14328491)
- Risks of not disclosing: YouTube may add the label itself, and creators who repeatedly fail to disclose risk content removal, YPP suspension or other penalties. This is stated on the help page, not in the 2026-05-27 blog post. [OFFICIAL] (answer/14328491)
- YPP risk for AI content comes from the inauthentic content rule (template-driven or repetitive output with no original view), not from the label. [OFFICIAL] (answer/1311392)
- Muse or Meta AI output: no source confirms whether Meta's exports carry C2PA credentials that YouTube reads. Assume YouTube may auto-label photoreal Muse clips. [INFERRED]
- Likeness: a privacy complaint path for AI that imitates an identifiable person has been reported. It was not re-verified this session. [REPORTED, unverified]

## Ranker's predict-checklist
1. Does the first frame make sense and grab attention without sound, so a swiper stops? (Viewed vs swiped away)
2. Is the core payoff delivered before most viewers would drop off, with no slow intro? (AVD, percentage viewed)
3. Would a viewer feel the time was well spent, not baited? (valued watch time)
4. Does it have a clear topic that lets the seed audience be matched? (audience fit)
5. Is it different enough from the channel's other Shorts to avoid the inauthentic content rule? (YPP)
6. If it is photoreal AI showing real people, places or events, is "AI use" set to Yes? (disclosure)
7. Are text and faces inside the reported safe area, clear of the right rail and the bottom band? (safe zones)
8. Is it 3 minutes or under, vertical or square, and free of Content ID-claimed music beyond 1 minute? (format, blocking)
9. Does it use at most a few relevant hashtags and a title that describes the content? (discovery, tag rules)
10. Is a Related Video link set to carry viewers to long-form, instead of a URL in the description? (links)
11. Is this a new upload, not a delete-and-repost of a weak Short? (spam risk)

## Primary URLs to re-check
- https://blog.youtube/creator-and-artist-stories/debunking-common-myths-about-youtube-shorts/ - separate rec systems, audio, monetization (2025-05-06), read 2026-11-25
- https://blog.youtube/news-and-events/improving-ai-labels-viewers-creators/ - AI label placement, auto-labels, no reach effect (2026-05-27), read 2026-11-25
- https://blog.youtube/inside-youtube/engaged-views-youtube-explained/ - views vs engaged views (2026-08-19), read 2026-11-25
- https://support.google.com/youtube/answer/14328491 - AI use disclosure and penalties, read 2026-11-25
- https://support.google.com/youtube/answer/1311392 - YPP inauthentic and reused content, read 2026-11-25
- https://support.google.com/youtube/answer/12220281 - Viewed vs swiped away metric, read 2026-11-25
- https://support.google.com/youtube/answer/15424877 - Shorts length and Content ID blocking, read 2026-11-25
- https://support.google.com/youtube/answer/13748639 - clickable elements in Shorts, read 2026-11-25
- https://support.google.com/youtube/answer/14075157 - Related Video link, read 2026-11-25
- https://support.google.com/youtube/answer/16722303 - brand links for sponsored Shorts, read 2026-11-25
- https://support.google.com/youtube/answer/6390658 - hashtag rules, read 2026-11-25
- https://blog.youtube/news-and-events/tall-updates-coming-to-shorts/ - 3-minute Shorts from 2024-10-15 (early Oct 2024), read 2026-11-25
- https://techcrunch.com/2023/08/25/youtube-demystifies-the-shorts-algorithm-views-and-answers-other-creator-questions (secondary) - Sherman on seed audience, timing, reposting, read 2026-11-25
- https://ppc.land/youtube-shorts-product-lead-discusses-strategy-and-metrics (secondary) - Sherman on feed coherence and valued watch time (2025-01-29), read 2026-11-25
