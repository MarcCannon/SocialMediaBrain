# Facebook - ranking brief
last_verified: 2026-11-25
disclosure: medium - Meta publishes system cards (Feed, recommendations, Reels) naming prediction targets and sample signals, plus demotion guidelines; no code, weights or combination formula
scoring rows: Facebook  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages
1. Connected Feed (friends, followed Pages, joined groups). [OFFICIAL] Feed system card, updated 2026-10-06
   - Inventory: posts from those sources. Posts that violate the Community Standards are excluded.
   - Signals: a lightweight model narrows the pool to roughly 500 posts. Integrity processes reduce problematic content here.
   - Predictions: several models estimate relevance and value per post.
   - Score: each post gets a relevance score; the feed is then mixed so one format does not repeat many times in a row.
2. Recommended (unconnected) Feed content runs on a separate system. Suggested content and ads are not powered by the connected-Feed system. [OFFICIAL] Feed card 2026-10-06
   - Inventory is a portion of public content. Anything breaking the Community Standards or the Recommendation Guidelines is excluded. [OFFICIAL] recommendations card, updated 2026-06-24
   - Eligibility requires the post to be public and to pass those guidelines. [OFFICIAL]
3. Reels. [OFFICIAL] Reels system card, updated 2026-06-19
   - Inventory: reels from followed accounts, reels similar to ones you engaged with, and reels from similar accounts. Instagram recommendations can appear.
   - A lightweight model picks about 10-100 reels using signals such as reel length, similarity and interest fit.
   - Three recommenders predict watch, completion, like, skip, hide, share and session actions; a relevance score orders the result.
4. Integrity demotions apply across surfaces through the Content Distribution Guidelines (CDGs). [OFFICIAL] types-of-content-we-demote, updated 2025-07-02
5. Originality enforcement (March 2026): unoriginal content is deprioritized in Feed and Reels, and accounts can become non-recommendable or demonetized. [OFFICIAL] about.fb.com, 2026-03-12/13
6. Viewer controls feed back into ranking: Hide, Snooze, Unfollow, Report, Interested / Not Interested, Favorites, and a chronological "Following" view. [OFFICIAL] Feed card 2026-10-06

## Top signals (ranked)
Meta names predictions and example signals but publishes no weights. The order below is [INFERRED] from how often each target recurs across the three cards.

| # | Signal | What it means for a post | Tag | Source + date |
|---|---|---|---|---|
| 1 | Scroll past rather than engage | The first two Feed predictions. Signals include average time per post and how often you quickly scrolled past the same friend in the last 7 days. A post must stop the thumb. | [OFFICIAL] | Feed card 2026-10-06 |
| 2 | Watch time and completion (Reels) | Several heads predict how long and how much of a reel you will watch, and whether you finish. Completions and skip rate by other viewers are inputs. | [OFFICIAL] | Reels card 2026-06-19 |
| 3 | Time spent on a post (recommended) | The first prediction for unconnected content. Content type and video length are inputs. | [OFFICIAL] | Recommendations card 2026-06-24 |
| 4 | Shares, including private shares | Predicted shares (recommendations), shares to WhatsApp and Messenger, and how many people you share with on Messenger (Reels). | [OFFICIAL] | Recs card 2026-06-24; Reels card 2026-06-19 |
| 5 | Comment quality and relevance | Average comment length and how relevant comments are to the post topic are named signals; comment count is an input to the format-adjusted scroll-past prediction. | [OFFICIAL] | Feed card 2026-10-06 |
| 6 | Relationship with the author | Intent to interact with friends or groups uses your past interactions with the author, including public ones. | [OFFICIAL] | Feed card 2026-10-06 |
| 7 | Negative feedback | Predicted "X" hides (recs), see less, hide, skip-and-leave (Reels), plus Not Interested controls. | [OFFICIAL] | Recs card; Reels card; Feed card |
| 8 | Originality | An input to the Reels like and ad-click predictions. Unoriginal content is deprioritized by policy. | [OFFICIAL] | Reels card 2026-06-19; about.fb.com 2026-03 |
| 9 | Likes | Predicted on both recommended Feed and Reels; uses your topic likes and likes you gave the creator. | [OFFICIAL] | Recs card; Reels card |
| 10 | Full-screen click and keep watching | Feed predicts a click into full screen; Reels predicts the click and continued watching. Watching original stories is a Feed signal. | [OFFICIAL] | Feed card 2026-10-06; Reels card |
| 11 | Save-like actions: screenshot, RSVP, join group, "Show more" | Recommended content is scored on screenshots (save counts are an input), RSVPs, group joins and "Show more" taps. | [OFFICIAL] | Recs card 2026-06-24 |
| 12 | Outside-link click and time on site | Feed predicts a link click and how long you stay; the card shows no link penalty. | [OFFICIAL] | Feed card 2026-10-06 |

## Negative signals and penalties
- Published demotions now number four (the July 2025 list). [OFFICIAL] types-of-content-we-demote, 2025-07-02
  - Clickbait links; engagement bait (direct-feedback items)
  - Fact-checked misinformation
  - Content likely to violate the Community Standards
- Engagement bait = posts that explicitly ask for votes, shares, comments, tags, likes or reactions. [OFFICIAL] engagement-bait page (undated)
  - Exempt: rallying support for an issue, disaster information, missing persons, fundraising, petitions.
  - The page states no specific reach consequence.
- Clickbait links = headlines that withhold information, sensationalise, or use all caps and excessive exclamation marks. [OFFICIAL] clickbait-links page (undated)
- Unoriginal content (March 2026 rules). [OFFICIAL] about.fb.com 2026-03-12/13
  - Unoriginal: re-uploads; minor edits such as borders, captions or speed changes; watch-alongs, facial reactions, stitching, or narrating what is already on screen.
  - Original: filmed or produced by the account owner, or third-party material where an on-screen creator adds new information, analysis or storyline.
  - Consequences: deprioritized in Feed and Reels; the account may become non-recommendable or lose monetization; appeals exist.
- Repeated reuse (July 2025). [OFFICIAL] creators.facebook.com, 2025-07-14
  - Repeat reusers lose monetization for a period and get reduced distribution on everything they share.
  - Duplicate videos get reduced distribution; attribution links to the original were being tested.
  - Adding your own watermark or stitching clips does not make content original. Avoid visible third-party watermarks and content recycled from other apps.
  - Keep captions relevant, avoid excessive capitals, and use no more than five relevant hashtags.
- Fact-checking changed. [OFFICIAL] about.fb.com, 2025-01-07, updated 2025-05-29
  - US third-party fact-checking ended in favour of Community Notes; fact-checked content is no longer demoted there.
  - Most predicted-violation demotions were dropped, and more confidence is needed before demoting.
  - [INFERRED] The July 2025 CDG page still lists fact-checked misinformation, so that demotion likely still applies outside the US.
- Removed guidelines: in July 2025 Meta dropped 14 CDGs, including click-gap domains, suspicious virality, low-quality comments, inauthentic sharing and repeat-violator content. [OFFICIAL] cdgs-changes-corrections. [INFERRED] Do not score those as published penalties; viewer feedback can still sink such posts.
- Links: a small test caps professional-mode profiles and Pages without Meta Verified at two organic link posts per month; links in comments are allowed and publishers are excluded. [REPORTED] TechCrunch 2025-12-17 (some coverage says per day: conflict). The creators blog also advises avoiding links. [OFFICIAL] 2025-07-14
- Integrity processes reduce problematic content at the signal stage; method not detailed. [OFFICIAL] Feed card 2026-10-06

## Format specs and safe zones
| Format | Ratios | Length limits | Caption limit / "see more" cut-off | Hashtag norms | Alt text |
|---|---|---|---|---|---|
| Text / status post | n/a | Character limit unverified [REPORTED] | "See more" cut-off unverified [REPORTED] | Five or fewer, relevant [OFFICIAL] 2025-07-14 | n/a |
| Feed image | 4:5 vertical commonly advised; ad-spec sites disagree [REPORTED] | Unverified | Same as text post | Same | Field and limit unverified [REPORTED] |
| Reel / video | 9:16 full screen; 1080x1920 commonly advised [REPORTED]. Keep the bottom 35% free of text and logos [OFFICIAL] reels-ads doc | All new videos post as Reels, no length or orientation limit [REPORTED] TechCrunch 2025-06-17. Organic reels eligible for ad promotion must be 9:16 and under 90 s [OFFICIAL] reels-ads doc (undated) | Unverified | Same | Unverified |
| Story | Unverified | Unverified | Unverified | Same | Unverified |
| Link post | Preview image ratio unverified | Possible cap of two organic link posts per month for some accounts [REPORTED] test, 2025-12-17 | Same as text post | Same | n/a |

## Native formats the platform pushes
- Original Reels. Meta reports original Reels views and time roughly doubled (H2 2025 vs H2 2024) and says transformative creators may get increased distribution. [OFFICIAL] about.fb.com 2026-03
- Video is Reels by default: the Video tab became Reels and new uploads post as Reels. [REPORTED] TechCrunch 2025-06-17
- Shareable content: private shares to Messenger and WhatsApp are explicit predictions. [OFFICIAL] Reels and recs cards
- Groups: Feed predicts intent to engage with group posts, and recommendations predict group joins. [OFFICIAL] Feed card; recs card
- Cross-app reach: Facebook Reels can include Instagram recommendations. [OFFICIAL] Reels card 2026-06-19
- Format variety: Feed mixes content types, so [INFERRED] a strong photo or text post is not crowded out by video by default.

## AI-generated content: labels, rules, consequences
- Label triggers. [OFFICIAL] about.fb.com, Nick Clegg, 2024-02-06
  - Industry signals: C2PA and IPTC "AI generated" metadata from Google, OpenAI, Microsoft, Adobe, Midjourney and Shutterstock.
  - Meta AI photorealistic images get "Imagined with AI" plus visible markers, invisible watermarks and metadata.
  - Users must self-disclose photorealistic video and realistic audio made with AI; Meta may apply penalties if they do not.
  - High-risk deceptive content may get a more prominent label.
- Label name and placement. [OFFICIAL] about.fb.com, Monika Bickert, 2024-04-05 with dated updates
  - "Made with AI" became "AI info" on 2024-07-01.
  - From 2024-09-12, AI-edited content shows the label in the post menu; AI-generated content keeps a visible label that says whether industry signals or self-disclosure triggered it.
  - Meta prefers labels and context over removal.
- Reach effect: no Meta source says the AI info label lowers ranking. [INFERRED] Treat the label as neutral.
- Fact-checkers could rate AI content False or Altered, which lowered it in Feed. [OFFICIAL] 2024-04-05. US fact-checking has since ended. [OFFICIAL] 2025-01-07
- Metadata can be stripped on upload, so C2PA/IPTC labels may not fire. [REPORTED] IPTC
- Meta Muse. [OFFICIAL] ai.meta.com, 2026-07-07
  - Muse Image output carries Meta's invisible Content Seal watermark, said to survive crops, compression, resizing and screenshots; a detection preview exists.
  - Muse Video was announced as coming soon.
  - Content Seal is not compatible with C2PA or SynthID; there is no visible watermark; Muse Image was "coming soon" to Facebook. [REPORTED] Engadget 2026-07-07
  - Whether Facebook's AI info label fires on Muse output: unverified. [INFERRED]
- Originality rules do not mention AI. [OFFICIAL] 2025-07-14 and 2026-03. [INFERRED] AI content the account produces itself is not excluded by the definitions; AI remakes of others' clips with minor edits risk the unoriginal rules.

## Ranker's predict-checklist
1. Will a viewer stop scrolling within the first second (scroll-past prediction)?
2. For a reel: will people watch to the end rather than skip, and does it hook before the bottom-35% UI zone matters?
3. Would someone share it privately on Messenger or WhatsApp?
4. Will it draw long, on-topic comments rather than one-word replies?
5. Is it original: filmed or produced by the account, or does it add new information, analysis or storyline?
6. Is it free of re-uploads, third-party watermarks, minor-edit remixes and recycled content from other apps?
7. Does the caption avoid explicit asks to like, share, comment, tag or vote (unless a listed exemption applies)?
8. Is any link headline free of withheld information, sensationalism, all caps and exclamation stacks?
9. Are there five or fewer relevant hashtags and minimal capitals?
10. Would a non-follower risk hitting hide, "X" or see less on it?
11. Is realistic AI video or audio self-disclosed, and is the AI info label acceptable to this audience?
12. Is the post public and compliant enough to be eligible for recommendations beyond connections?

## Primary URLs to re-check
- https://transparency.meta.com/features/explaining-ranking/fb-feed/ - connected Feed system card (updated 2026-10-06, read 2026-11-25)
- https://transparency.meta.com/features/explaining-ranking/fb-feed-recommendations/ - recommended content card (updated 2026-06-24, read 2026-11-25)
- https://transparency.meta.com/features/explaining-ranking/fb-reels/ - Reels card (updated 2026-06-19, read 2026-11-25)
- https://transparency.meta.com/features/approach-to-ranking/types-of-content-we-demote/ - the four CDGs (updated 2025-07-02, read 2026-11-25)
- https://transparency.meta.com/features/approach-to-ranking/cdgs-changes-corrections/ - CDG change log (read 2026-11-25)
- https://transparency.meta.com/features/approach-to-ranking/content-distribution-guidelines/engagement-bait/ - engagement bait (read 2026-11-25)
- https://transparency.meta.com/features/approach-to-ranking/content-distribution-guidelines/clickbait-links/ - clickbait links (read 2026-11-25)
- https://about.fb.com/news/2026/03/rewarding-original-creators-on-facebook/ - originality rules (2026-03-12/13, read 2026-11-25)
- https://creators.facebook.com/blog/combating-unoriginal-content - reuse penalties and tips (2025-07-14, read 2026-11-25)
- https://about.fb.com/news/2024/04/metas-approach-to-labeling-ai-generated-content-and-manipulated-media/ - AI info label (2024-04-05 with updates, read 2026-11-25)
- https://about.fb.com/news/2024/02/labeling-ai-generated-images-on-facebook-instagram-and-threads/ - label triggers (2024-02-06, read 2026-11-25)
- https://about.fb.com/news/2025/01/meta-more-speech-fewer-mistakes/ - fact-checking and demotion changes (2025-01-07, read 2026-11-25)
- https://ai.meta.com/blog/introducing-muse-image-muse-video-msl/ - Muse and Content Seal (2026-07-07, read 2026-11-25)
- https://developers.facebook.com/documentation/ads-commerce/marketing-api/creative/reels-ads - Reels ratio and safe zone (undated, read 2026-11-25)
