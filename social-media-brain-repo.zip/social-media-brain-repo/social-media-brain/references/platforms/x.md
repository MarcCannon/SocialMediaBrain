# X (Twitter) - ranking brief
last_verified: 2026-11-25
disclosure: high - the For You pipeline, action weights, filters and safety-label rules are open source (xai-org/x-algorithm, Apache-2.0); model weights and Grok/grox prompts are not
scoring rows: X  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages
1. Candidate sourcing. In-network posts (accounts the viewer follows) come from Thunder; out-of-network (OON) posts come from Phoenix two-tower retrieval, SimClusters and a popular-posts source. [CODE] home-mixer, xai-org/x-algorithm, read 2026-11-25
2. Since 2026-10-13, Phoenix retrieval is also trained to surface posts people read all the way through. [CODE] README changelog
3. Pre-rank filters remove: posts older than 48 hours (AgeFilter), posts already seen or served, muted keywords, blocked or muted authors, OON retweets and replies, duplicate conversations and self-reply chains. For new or returning viewers, an optional filter drops OON posts whose like-to-view ratio is under 0.004. [CODE] home-mixer/filters, home-mixer/params/param.rs
4. Phoenix ranking. A Grok-based transformer predicts, for each post, the probability of every action in the weight table below. It scores each candidate in isolation (candidates cannot see each other) and uses hash embeddings. Since 2026-10-08 it predicts time spent better. [CODE] phoenix/, README
5. Weighted score = sum of (predicted probability x action weight). ValueModelMode defaults to "weighted"; a multiplicative mode exists but is off. [CODE] home-mixer/params/param.rs (weights published 2026-08-13)
6. Re-rank (vm-ranker):
   - Author diversity multiplier: (1 - 0.25) x 0.5^n + 0.25, where n = how many of that author's posts already ranked above. [CODE] vm-ranker/params.rs
   - OON posts are multiplied by 0.75; topic OON posts by 0.5. [CODE]
   - A DPP step adds variety. [CODE]
7. Author cold start (on by default). In each request, at most one post can be lifted to the score held by roughly rank 15-16. Eligible posts are original posts (not replies or reposts) from authors with 50,000 or fewer followers, at most 7200 s (2 h) old, with under 200 home impressions. Selection uses Thompson sampling on likes per view. [CODE] home-mixer/scorers/author_cold_start.rs
8. Visibility filtering. Safety labels resolve to ALLOW, NOTICE, INTERSTITIAL or DROP. Labelled authors and posts are dropped from OON recommendations (see the AI section). [CODE] visibility-filtering/, abuse-enforcement-service/
9. Blending. ForYouCandidatePipeline mixes the ranked posts with ads and other modules. [CODE]
10. Replies under a post are ranked by a separate Phoenix reply model plus a grox (Grok 4 mini) reply score; see signal 10. [CODE] phoenix/crates/common/xai-recsys/src/reply.rs
11. Since 2026-08-13, the "Under the Hood" tool shows creators the labels limiting their account or posts. Since 2026-09-18 it also shows legal withholding by country. [CODE] README

## Top signals (ranked)
Weights multiply the viewer's own predicted probability, not raw counts. A big weight on a rare action does not automatically dominate. [CODE] README 2026-08-14 note; param.rs comments

| # | Signal | What it means for a post | Tag | Source + date |
|---|---|---|---|---|
| 1 | Reply (5.0), rising to 20.0 for a reply from a mutual follow | Replies are the strongest common action. The +15.0 mutual-follow boost applies only to original posts (not replies or reposts) when viewer and author follow each other. Write posts people in your network want to answer. | [CODE] | param.rs, xai-value-model weights.rs + inputs.rs; boost tested 2026-07-10, 20 from 07-13, 15 from 07-24 |
| 2 | Share via copy link (20.0), share via DM (5.0), share (2.118) | Copy-link sharing has the highest positive weight. Make posts worth sending out of the app: useful, referenceable, funny. | [CODE] | param.rs, 2026-08-13 |
| 3 | Quote (5.0) | Quotes count like replies. A clear take invites quote commentary. | [CODE] | param.rs |
| 4 | Follow author (4.0) | Posts that make a stranger follow you score well. A distinct voice and an obvious niche help. | [CODE] | param.rs |
| 5 | Repost (1.0) and like (0.708) | Likes are the most likely action, but each carries little weight. Like-farming alone is weak. | [CODE] | param.rs |
| 6 | Time spent: click-then-dwell (0.385), click (0.274), dwell (0.05), continuous dwell time (0.0075), photo expand (0.05) | Content that holds attention after a tap pays. Dense images, threads and long posts benefit when they are actually read. | [CODE] | param.rs; time-spent model improved 2026-10-08 |
| 7 | Negative predictions: report (-234.0), mute author (-58.8), not interested (-53.07), block author (-31.2), not dwelled (-0.02) | One predicted mute or "not interested" outweighs many likes. Rage-bait and off-topic spam aimed at strangers is penalised hardest. | [CODE] | param.rs; a code comment says report base rates are over 1000x lower than likes |
| 8 | OON discount (0.75) and author diversity decay (0.5, floor 0.25) | Reach outside followers starts at a discount; posting many times in a row gives diminishing returns per post in a session. | [CODE] | vm-ranker/params.rs |
| 9 | Freshness: 48 h age filter; 2 h small-author cold-start window | Posts have about two days to be ranked. Small accounts get one lift slot only in the first 2 h and under 200 impressions. | [CODE] | age_filter.rs, author_cold_start.rs |
| 10 | Reply ranking: grox score, author_verified (4 levels), liked by the root author, focal-author replies, follower count, negative feedback | In threads, verified and Premium authors' replies rank higher, and so do replies the original author likes or answers. | [CODE] + [OFFICIAL] | reply.rs; help.x.com x-premium ("slight preference" for verified replies) |
| 11 | Zero-weight actions: video open, video quality view, profile click, Grok analyze, post video | Views and profile taps add nothing directly; video only scores through dwell, shares and replies. | [CODE] | param.rs (VQV needs 10 s minimum video when enabled) |
| 12 | Open link (0.2) | Link taps are a small positive; there is no link penalty term in the scorer. | [CODE] | param.rs |

## Negative signals and penalties
- Links: the open scorer has no link penalty, and OpenLink is +0.2. [CODE] param.rs
- Link statements:
  - Product head Nikita Bier denied a link deboost and blamed lower engagement. [REPORTED] Nieman Lab, 2025-10-20
  - In July 2026 Musk said X had not penalised links for over a year. [REPORTED] Free Press Journal, updated 2026-07-29
  - In 2023 Musk said links get less attention because the ranker optimises for time spent. [REPORTED] Axios, 2023-10-03
- [INFERRED] Link posts can still lose indirectly: people leave the app, so dwell, reply and repost predictions drop.
- Spam behaviours named by policy can lead to reach limits or account restrictions. [OFFICIAL] help.x.com authenticity policy, April 2025
  - Repeatedly posting links without commentary.
  - Excessive, unrelated hashtags.
  - Using trending hashtags to hijack attention.
  - Editing links after posting so the destination changes.
- Reach-limit actions available to X: no search, trends or notifications; removed from For You and Following; visible only on the profile; downranked in replies. [OFFICIAL] authenticity policy
- Hide, mute, block, report and "not interested" are heavily negative prediction targets. Only Home Timeline engagement trains them. [CODE] param.rs comments
- Safety labels drop OON distribution for both authors and posts:
  - Author labels: SpamHighRecall, Compromised, ReadOnly, ImpersonationHighPrecision, AbusiveHighRecall, DoNotAmplify. [CODE] visibility-filtering rules
  - Post labels: DoNotAmplify, MaliciousUrl, SpamHighRecall. [CODE]
- New-viewer filter: OON posts with a weak like-to-view ratio can be cut for new or returning viewers. [CODE] new_user_min_engagement_filter.rs
- Watermarks and reposted content: no dedicated originality or watermark penalty was found in the open code. [INFERRED] from CODE search; unverified
- The weights changed after publication: the README's 2026-08-14 report-vs-like example does not match current param.rs values. Treat all weights as a dated snapshot. [INFERRED] from CODE

## Format specs and safe zones
| Format | Ratios | Length limits | Caption limit / "see more" cut-off | Hashtag norms | Alt text |
|---|---|---|---|---|---|
| Text post | n/a | 280 characters (free); up to 25,000 with Premium long posts [OFFICIAL] | Long-post "Show more" cut-off point: unverified [REPORTED]. The how-to-post page also mentions 4,000, conflicting with 25,000 [OFFICIAL] | "Excessive" hashtags count as spam; no number given [OFFICIAL] | n/a |
| Single image | Shown uncropped between 2:1 and 3:4 [OFFICIAL] | Up to 5MB per photo [OFFICIAL] | Same text limits as a post | Same | Up to 1,000 characters per image [OFFICIAL] |
| Multi-image | Grid; per-image crop rules unverified | 1-4 photos per post (up to 4 media items) [OFFICIAL] | Same | Same | Per image, 1,000 characters [OFFICIAL] |
| GIF | n/a | 5MB on mobile, 15MB on web [OFFICIAL] | Same | Same | Supported via picture descriptions [OFFICIAL] |
| Video | 1:2.39 to 2.39:1 [OFFICIAL] | Free: 140 s, 512MB. Premium: under 4 h and 16GB, 1080p up to 2 h, per x-videos page [OFFICIAL]; the Premium page says about 3 h and 8GB (conflict) [OFFICIAL]. Videos of 60 s or less loop [OFFICIAL] | Same | Same | Video alt text: unverified |
| Article | n/a | Premium-tier feature; the help page lists Premium+ in one place and Premium in another (conflict) [OFFICIAL] | Length limit unverified | Same | Unverified |

## Native formats the platform pushes
- Conversation. The reply weight and the mutual-follow reply boost reward posts that start back-and-forth discussion with people you know. [CODE]
- Shareable posts. DM and copy-link sharing carry the largest positive weights. [CODE]
- Read-through content. The time-spent work (2026-10-08) and read-through retrieval (2026-10-13) favour posts people finish. [CODE] README
- Video only through attention. Video open and video-view weights are zero, so video wins only via dwell, shares and replies. [CODE] param.rs. [INFERRED] Hooks in the first seconds matter.
- Premium long posts, Articles and longer video are paid features. The For You weighted scorer has no Premium term. [CODE] Any reach effect comes through reply prioritisation and engagement. [OFFICIAL] help.x.com x-premium
- [REPORTED] A Buffer study of about 18.8M posts (Oct 2025) found Premium accounts get more reach. Correlation only.

## AI-generated content: labels, rules, consequences
- Policy: the authenticity policy covers synthetic and manipulated media, including AI fakes of real people. [OFFICIAL] help.x.com, April 2025
  - It bans media that is deceptively altered or fabricated when it can cause public confusion or serious harm. Fabricated or AI-simulated depictions of a real person are named explicitly. [OFFICIAL]
  - Sharing manipulated media in non-deceptive ways is allowed. [OFFICIAL]
  - Enforcement can include reach restriction, feature limits and removal. A visible AI label is not listed as an enforcement option. [OFFICIAL]
  - AI-generated profile photos used to deceive count as a manufactured identity. [OFFICIAL]
  - Parody, commentary and fan (PCF) accounts need a PCF label and must say "parody", "fan" or similar in the account name and bio. The PCF label also feeds the model input. [OFFICIAL] + [CODE] grox renderer_v82.py
- AI-slop enforcement (in code):
  - `llm_slop_user` puts SpamHighRecall on an account for 7 days. [CODE] enforcement_user.yaml
  - `llm_slop_post` puts RiskyHighVizReply on a post for 30 days. [CODE] enforcement_post.yaml
  - SpamHighRecall is an OON author drop, so a flagged account loses For You reach to non-followers for that week. [INFERRED] from CODE
- A grox Gemma screen emits a slopScore for posts. No scorer was found using it directly. [CODE] grox/
- Armed conflict: paid creators must label AI-made armed-conflict videos. The penalty is 90 days without revenue sharing, and repeat offenders are removed permanently. [REPORTED] Engadget, 2026-03-03
- Musk teased a label for edited images; whether it shipped is unverified. [REPORTED] TechCrunch, 2026-01-28
- No source states that an AI label by itself lowers ranking. [INFERRED] Do not assume a label penalty; the risk is slop flags and negative feedback.
- Meta Muse output carries Meta's invisible Content Seal watermark, not C2PA. Whether X reads Content Seal: unverified. [OFFICIAL] ai.meta.com 2026-07-07; [REPORTED] Engadget 2026-07-07
- [INFERRED] Generic, templated Muse images posted at volume fit the slop pattern; a real person's likeness without parody framing risks the authenticity policy.

## Ranker's predict-checklist
1. Will people in the author's own network want to reply to this original post (mutual-follow reply boost)?
2. Would someone copy the link or DM it to a friend?
3. Does it invite quotes with a clear, arguable take?
4. Would a stranger follow the author after seeing it?
5. Does it hold attention after a tap (dense image, thread, long post read to the end)?
6. Could a non-follower see it as spam, bait or off-topic and mute, block, report or tap "not interested"?
7. Is it free of link-only, hashtag-stuffed or edited-link patterns?
8. Is it the author's only post in this burst (author diversity decay)?
9. If the author is small (50,000 followers or fewer), is the post original rather than a reply, and strong in its first 2 h?
10. Does a video earn dwell and shares on its own, without relying on views?
11. Would it read as generic AI slop, or misrepresent a real person without parody framing?
12. Does the media fit the uncropped image range (2:1 to 3:4) with alt text written?

## Primary URLs to re-check
- https://github.com/xai-org/x-algorithm - pipeline, weights, filters, slop labels, changelog (read 2026-11-25)
- https://github.com/xai-org/x-algorithm/blob/main/home-mixer/params/param.rs - action weights and params (read 2026-11-25)
- https://github.com/xai-org/x-algorithm/blob/main/vm-ranker/params.rs - diversity and OON factors (read 2026-11-25)
- https://help.x.com/en/rules-and-policies/authenticity - synthetic media, spam, reach limits (read 2026-11-25)
- https://help.x.com/en/using-x/x-premium - reply prioritisation, long posts, Articles (read 2026-11-25)
- https://help.x.com/en/using-x/how-to-post - character and media limits (read 2026-11-25)
- https://help.x.com/en/using-x/posting-gifs-and-pictures - image specs (read 2026-11-25)
- https://help.x.com/en/using-x/x-videos - video specs (read 2026-11-25)
- https://help.x.com/en/using-x/picture-descriptions - alt text (read 2026-11-25)
