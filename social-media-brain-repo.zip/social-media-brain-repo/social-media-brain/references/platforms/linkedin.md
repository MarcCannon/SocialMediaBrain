# LinkedIn - ranking brief
last_verified: 2026-11-25
disclosure: medium - architecture, prediction targets and policies are published (engineering blog, arXiv, help center), but no code or weights
scoring rows: LinkedIn  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages
1. Inventory. Posts from your network, follows and unconnected authors are all candidates. Retrieval explicitly recalls relevant posts from people outside the viewer's network. [OFFICIAL] LinkedIn Engineering, 2026-03-12
2. LLM retrieval. One fine-tuned LLM dual encoder replaced the older separate sources (trending, collaborative filtering, network, topic, embeddings). [OFFICIAL] Engineering, 2026-03-12
   - Members and posts are turned into templated text prompts and matched by cosine similarity.
   - Post inputs include format, author headline, company and industry, engagement counts (as percentile buckets) and the post text.
   - Member inputs include profile signals (industry, skills, experience, geography) and engagement history. [OFFICIAL] news.linkedin.com, 2026-03-12
   - Embeddings refresh nearline within minutes. Retrieval runs in under 50 ms, and Recall@10 rose 15%. [OFFICIAL]
3. Sequential ranking. A Generative Recommender (GR) transformer reads the member's ordered history of more than 1,000 past interactions. [OFFICIAL] Engineering, 2026-03-12
   - An MMoE head per engagement type predicts passive actions (click, skip, long dwell) and active actions (like, comment, share). [OFFICIAL]
   - The Feed-SR paper reports this ranker replaced DCNv2 and served most Feed traffic for more than 3 months. [OFFICIAL] arXiv 2602.12354, v3 2026-09-16
   - In its A/B test: time spent +2.10%; members liking, commenting or resharing +3.52%. [OFFICIAL] arXiv 2602.12354
   - [INFERRED] The blog's GR ranker and the paper's Feed-SR appear to describe the same system.
4. Quality and integrity layer:
   - Engagement pods, comment automation, recycled or click-driven low-substance posts, engagement bait and mismatched video are demoted. [OFFICIAL] 2026-03-12 and 2026-03-13
   - Automated comments may be excluded from "Most Relevant". [OFFICIAL] 2026-03-13
5. Low-harm false content stays inside the author's network and is not distributed beyond it. Harmful misinformation is removed. [OFFICIAL] help a1340752
6. Video feed. You cannot post into it directly; any video may become eligible based on relevance and performance. [OFFICIAL] help a6290168
7. 360Brew (a 150B-parameter "research pre-production" model) is not confirmed live. All arXiv versions (v1 2025-01-27 to v4 2025-08-23) are withdrawn. [OFFICIAL] arXiv 2501.16450; live status unverified

## Top signals (ranked)
| # | Signal | What it means for a post | Tag | Source + date |
|---|---|---|---|---|
| 1 | Predicted long dwell / time spent | A passive training target. Feed-SR was judged mainly on time spent. Posts that get read to the end win. | [OFFICIAL] | Engineering 2026-03-12; arXiv 2602.12354 |
| 2 | Predicted comments (genuine) | An active target. Automated or pod comments are discounted or hidden, so only real discussion helps. | [OFFICIAL] | Engineering 2026-03-12; news 2026-03-13 |
| 3 | Topic match to the member's professional profile | LLM retrieval matches post text to industry, skills, experience and geography. Clear, on-niche language gets recalled. | [OFFICIAL] | news + Engineering 2026-03-12 |
| 4 | Predicted shares / reshares | An active target. Content worth passing to colleagues travels further. | [OFFICIAL] | Engineering 2026-03-12 |
| 5 | Predicted likes / reactions | An active target. It counts, but it is only one of several heads. | [OFFICIAL] | Engineering 2026-03-12 |
| 6 | Predicted clicks | A passive target ("see more", media, profile or link taps; the exact click types are unspecified). | [OFFICIAL] | Engineering 2026-03-12 |
| 7 | Predicted skips | A passive target that works against a post. A weak opening line or an off-topic image invites skips. | [OFFICIAL] | Engineering 2026-03-12 |
| 8 | Author identity: headline, company, industry | These are inputs to the post embedding. Author relevance to the topic matters. | [OFFICIAL] | Engineering 2026-03-12 |
| 9 | Early engagement counts (percentile-bucketed) | Popularity is an input, bucketed rather than raw. | [OFFICIAL] | Engineering 2026-03-12 |
| 10 | Format, plus video-text match | Format is a post input. Videos whose content does not match the post text are reduced. | [OFFICIAL] | Engineering + news 2026-03-12 |
| 11 | Originality and insight | Unoriginal, promotional-without-insight and recycled posts are not recommended. | [OFFICIAL] | linkedin.com/blog/content-recommendations-avoid (2026 footer) |
| 12 | Posting cadence and verification | Excessive posting or automation tools can limit visibility. Pages that hit a posting limit can improve visibility through verification. | [OFFICIAL] | help a528176 |

## Negative signals and penalties
- Engagement bait, such as "comment to agree" asks or reaction-vote polls, is reduced and not recommended. [OFFICIAL] news 2026-03-12; content-recommendations-avoid
- Pods: [OFFICIAL] news 2026-03-13
  - Participants get warnings and restrictions and can lose Top Voice status.
  - Posts boosted by pods are flagged and their reach limited.
- Automated comments may be left out of "Most Relevant" and hidden from people outside the commenter's network. [OFFICIAL] news 2026-03-13
- Excessive post creation or automation tools can lead to limited visibility. [OFFICIAL] help a528176
- The "avoid" list also covers: [OFFICIAL] content-recommendations-avoid
  - tagging people just for attention
  - exaggeration
  - irrelevant hashtags
  - derisive content
  - text-on-image memes, corporate memes and generic viral videos
  - adult or shocking content
- Unoriginal or recycled posts are not recommended. [OFFICIAL] news 2026-03-12; content-recommendations-avoid
- Links:
  - No official statement of a link penalty was found. [INFERRED] from search; unverified
  - Organic link previews appear smaller unless the post is promoted. [REPORTED] Social Media Today
- Watermarks: no LinkedIn source mentions a watermark penalty. [INFERRED]; unverified
- Low-harm false or misleading content is held to the author's network. [OFFICIAL] help a1340752
- Skips are trained as a negative passive target. [OFFICIAL] Engineering 2026-03-12

## Format specs and safe zones
| Format | Ratios | Length limits | Caption limit / "see more" cut-off | Hashtag norms | Alt text |
|---|---|---|---|---|---|
| Text post | n/a | 3,000 characters; use an Article for longer pieces [OFFICIAL] | "See more" at about 210 characters on desktop and about 140 on mobile: unverified [REPORTED] | Irrelevant hashtags are not recommended [OFFICIAL]; hashtag following was removed in 2024 [REPORTED] | n/a |
| Single image | 3:1 to 4:5; wider is centre-cropped; renders no taller than 4:5 [OFFICIAL] | 5MB; at least 552x276, 1080 px wide recommended [OFFICIAL] | Same as text post | Same | ALT button; character limit unverified [OFFICIAL] |
| Multi-image | Two images sit side by side. The first image sets the layout; the container is capped at 4:5 and the bottom row may be cropped [OFFICIAL] | Up to 20 images [OFFICIAL] | Same | Same | ALT per image [OFFICIAL] |
| Video | 1:2.4 to 2.4:1 [OFFICIAL] | 75KB to 5GB; 3 s (2 s on mobile) to 15 min; 192 Kbps to 30 Mbps [OFFICIAL] | Same | Same | Auto-captions in 10 languages; captions recommended [OFFICIAL] |
| Document (PDF carousel) | All pages must be the same size [OFFICIAL] | 100MB, 300 pages; PPT, PPTX, DOC, DOCX or PDF; title required; readers can download it [OFFICIAL] | Same | Same | Unverified |
| Poll | n/a | Question 140 characters, 2-4 options of 30 characters; runs 1 day, 3 days, 1 week or 2 weeks [OFFICIAL] | Same | Same | n/a |
| Article | n/a | For pieces over 3,000 characters [OFFICIAL]; other limits unverified | Unverified | Same | Unverified |

## Native formats the platform pushes
- Video:
  - LinkedIn has a dedicated vertical video feed; any video can qualify based on relevance and performance. [OFFICIAL] help a6290168
  - LinkedIn expanded vertical-video tools in Feb 2025 as video uploads rose. [REPORTED] TechCrunch 2025-02-04; Axios 2025-02-04
- Insightful, original professional text: the stated goal of the 2026 feed update was substantive posts over click-driven ones. [OFFICIAL] news 2026-03-12
- Posts from experts outside your network: the LLM retrieval was built to recall them by topic. [OFFICIAL] Engineering 2026-03-12. [INFERRED] A consistent niche helps the embedding place an author.
- Formats that earn dwell: long dwell is a training target. [OFFICIAL] [INFERRED] Readable documents and multi-image posts gain if people actually page through them.
- Polls are allowed, but polls that ask for reaction votes are on the avoid list. [OFFICIAL]

## AI-generated content: labels, rules, consequences
- What triggers the label: C2PA Content Credentials. [OFFICIAL] help a6282984
  - Images and videos cryptographically signed with C2PA show a C2PA icon, visible to all viewers.
  - Clicking it shows whether AI generated or edited the content, the app or device used, the creator, the issuer and the signing date.
  - The rollout is gradual. LinkedIn says it cannot yet identify and label all AI content.
  - The icon is often called "CR". That name is unofficial. [REPORTED]
- Reach effect: no source states that the C2PA icon changes ranking. [INFERRED] Treat it as neutral.
- Synthetic media rules: [OFFICIAL] help a1340752
  - Deceptive synthetic or manipulated media without clear disclosure is removed, including photorealistic content showing someone saying or doing what they did not.
  - Artistic or humorous synthetic media generally must be disclosed as fake or altered, unless the context makes obvious parody clear.
- Non-disclosure risks: removal if it distorts real events. If it is misleading but low-harm, it is limited to the author's network. [OFFICIAL] help a1340752
- AI in text and comments: comment automation is demoted and pods are penalised. [OFFICIAL] news 2026-03-12 and 2026-03-13. [INFERRED] AI-written generic posts risk the "recycled or low-substance" demotion.
- Video-text mismatch is reduced, so AI stock video unrelated to the post is a risk. [OFFICIAL] news 2026-03-12
- Meta Muse images carry Meta's invisible Content Seal, not C2PA. [OFFICIAL] ai.meta.com 2026-07-07; [REPORTED] Engadget 2026-07-07
  - [INFERRED] So a Muse image will not show LinkedIn's C2PA icon unless it also carries C2PA data (unverified).
  - The disclosure duty for realistic synthetic media still applies.

## Ranker's predict-checklist
1. Will a professional in the target industry read this to the end (long dwell)?
2. Does it invite genuine, substantive comments without asking for them ("comment X")?
3. Is the topic stated clearly enough in the text for LLM retrieval to match it to the right skills and industries?
4. Would someone reshare or send it to a colleague?
5. Does the opening line give a reason not to skip?
6. Is it original insight rather than recycled, promotional or meme content?
7. Is it free of pods, automated comments, tagging for attention and irrelevant hashtags?
8. Does the media match the post text, especially for video?
9. Is any realistic synthetic media disclosed, or clearly parody?
10. Does the image sit between 3:1 and 4:5, and does the document have same-size pages and a title?
11. Does the author's headline and industry fit the topic?
12. Is the author posting at a sustainable rhythm, not a burst that looks automated?

## Primary URLs to re-check
- https://news.linkedin.com/2026/ImprovingTheFeed - 2026 feed update and demotions (published 2026-03-12, read 2026-11-25)
- https://www.linkedin.com/blog/engineering/feed/engineering-the-next-generation-of-linkedins-feed - LLM retrieval and GR ranking (2026-03-12, read 2026-11-25)
- https://news.linkedin.com/2026/authentic-content-and-conversations - pods, automated comments (2026-03-13, read 2026-11-25)
- https://www.linkedin.com/blog/content-recommendations-avoid - what is not recommended (undated, read 2026-11-25)
- https://arxiv.org/abs/2602.12354 - Feed-SR paper (v3 2026-09-16, read 2026-11-25)
- https://arxiv.org/abs/2501.16450 - 360Brew, withdrawn (read 2026-11-25)
- https://www.linkedin.com/help/linkedin/answer/a6282984 - C2PA content credentials (read 2026-11-25)
- https://www.linkedin.com/help/linkedin/answer/a1340752 - misinformation and synthetic media (read 2026-11-25)
- https://www.linkedin.com/help/learning/answer/a528176 - posts, 3,000 characters, visibility limits (read 2026-11-25)
- https://www.linkedin.com/help/linkedin/answer/100983 - image specs (read 2026-11-25)
- https://www.linkedin.com/help/linkedin/answer/a7486279 - video specs (read 2026-11-25)
- https://www.linkedin.com/help/linkedin/answer/97459 - documents (read 2026-11-25)
- https://www.linkedin.com/help/linkedin/answer/a6290168 - video feed (read 2026-11-25)
- https://www.linkedin.com/help/linkedin/answer/119594 - polls (read 2026-11-25)
