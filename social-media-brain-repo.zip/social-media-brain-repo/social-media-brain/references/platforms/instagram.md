# Instagram - ranking brief
last_verified: 2026-11-25
disclosure: medium - Meta publishes per-surface system cards (stages, prediction lists, input signals) and Mosseri explains priorities, but no weights, formulas or thresholds for eligibility
scoring rows: Instagram Feed, Instagram Reels  (persona weights live in ../rubrics.md, not here)

Tags: [CODE] open-source code - [OFFICIAL] platform docs, papers, executives - [REPORTED] credible secondary - [INFERRED] our reasoning

## Distribution stages

### Feed (photos, carousels, in-feed video)
1. Inventory: posts from followed accounts are gathered and Community Guidelines violations are dropped. [OFFICIAL] IG Feed system card, updated 2026-06-29
2. A lightweight model keeps roughly 700 of the most relevant posts; integrity processes reduce distribution of problematic content at this step. [OFFICIAL] IG Feed card, 2026-06-29
3. Multi-task models predict a set of actions per post (see Top signals). Several signals check whether the post is a recommended post, so unconnected posts are scored in the same ranker. [OFFICIAL] IG Feed card, 2026-06-29
4. About 500 posts get a relevance score and are sorted; the system also keeps a balanced mix of content types. [OFFICIAL] IG Feed card, 2026-06-29
5. Non-follower discovery for photos and carousels runs largely through Explore: retrieval of up to 1500 candidates, an early stage that keeps the top 100, then a multi-task late-stage ranker. [OFFICIAL] IG Explore card, updated 2026-06-22
6. Recommendation gate: an account that mainly posts unoriginal content loses recommendation eligibility on every surface (photos and carousels as well as reels); follower distribution is unaffected. [OFFICIAL] Instagram Creators blog, 2026-04-30

### Reels (Reels tab / Reels Chaining)
1. Inventory: reels from followed accounts plus reels similar to ones the viewer recently engaged with. [OFFICIAL] IG Reels Chaining card, updated 2025-11-11
2. A lightweight model keeps about 100 reels using reel length, similarity to other reels and match to the viewer's habits; integrity removes non-recommendable content. [OFFICIAL] Reels Chaining card, 2025-11-11
3. Multi-task predictions (see Top signals), then about 100 reels are scored and ordered, higher predicted value shown sooner. [OFFICIAL] Reels Chaining card, 2025-11-11
4. Length gate: reels longer than 3 minutes are not recommended to new audiences, so they reach followers only. [OFFICIAL] about.instagram.com/features/reels, read 2026-11-25
5. Optional Trial Reels route: the reel goes to non-followers first, stays off the grid and Reels tab, and can be shared to followers manually or automatically if it performs. [OFFICIAL] Meta newsroom, 2024-12-10
6. Viewer steering: "Your Algorithm" lets viewers add or remove topics; launched on Reels in the US 2025-12-10, Explore 2026-04-15, and all of Instagram (Feed, Reels, Explore) globally in English 2026-06-10. [OFFICIAL] Instagram blog, 2025-12-10 with updates

## Top signals (ranked)
Mosseri named three signals as the most important: watch time, likes per reach and sends per reach. Likes weigh more with followers; sends weigh more with non-followers. [REPORTED] Mosseri video, 2025-01, via Social Media Today and Buffer. Order inside each table is [INFERRED] from that statement plus the system cards; Meta publishes no weights.

### Feed
| # | Signal | What it means for a post | Tag | Source + date |
|---|--------|--------------------------|-----|---------------|
| 1 | Time spent on the post | Dwell drives "enjoy" and "time on post" predictions; the first post in a session is judged on whether it holds 10+ seconds and 3+ seconds | [OFFICIAL] | IG Feed card, 2026-06-29 |
| 2 | Likes per reach (positive actions) | Likes, comments and reshares feed the "enjoy" prediction; per Mosseri, likes matter most for follower reach | [OFFICIAL] / [REPORTED] | Feed card 2026-06-29; Mosseri 2025-01 |
| 3 | DM sends per reach | A predicted send via the share sheet; informative posts (news, reviews, tutorials, how-tos) and posts under 90 days old are named inputs; sends matter most for non-follower reach | [OFFICIAL] / [REPORTED] | Feed card 2026-06-29; Mosseri 2024-05 and 2025-01 |
| 4 | Full carousel swipe-through | Separate prediction; inputs are swipes, cards viewed and card count, so every slide must earn the next swipe | [OFFICIAL] | Feed card, 2026-06-29 |
| 5 | Skip probability | Skip is predicted relative to neighbouring posts and by media type; a weak first frame or opener loses | [OFFICIAL] | Feed card, 2026-06-29 |
| 6 | Profile visit and time on profile | Predicts time on the author's profile after the post; a reason to check the author out helps | [OFFICIAL] | Feed card 2026-06-29; Ranking Explained 2023-05-31 |
| 7 | Comments | Part of "enjoy" positive actions; listed by Mosseri as a Feed prediction | [OFFICIAL] | Feed card 2026-06-29; Ranking Explained 2023-05-31 |
| 8 | Sound turned on (video) | Predicts whether the viewer unmutes an in-feed video; video must work muted but reward sound | [OFFICIAL] | Feed card, 2026-06-29 |
| 9 | Text overlay on photos (Meta's signal; this skill never adds overlay text) | The amount of overlaid text is an input to time-on-post; the direction of the effect is not stated | [OFFICIAL] / [INFERRED] | Feed card, 2026-06-29 |
| 10 | Saves, likes, shares in Explore | Explore predicts save, like, reshare, follow, comment and dwell (over 5 s; over 11 s for reels, over 6 s for non-reels) for unconnected reach | [OFFICIAL] | IG Explore card, 2026-06-22 |

### Reels
| # | Signal | What it means for a post | Tag | Source + date |
|---|--------|--------------------------|-----|---------------|
| 1 | Watch time vs same-length reels | Predicts watching more than 95% of viewers of reels of the same length; Mosseri's top signal | [OFFICIAL] / [REPORTED] | Reels Chaining card 2025-11-11; Mosseri 2025-01 |
| 2 | Early hold (sub-3-second exits) | Predicts watching under 3 s; inputs include count of 3 s+ watchers, dismissals and skips within 2 s | [OFFICIAL] | Reels Chaining card, 2025-11-11 |
| 3 | Sends and shares | Separate predictions for reshare and for sharing off Instagram; sends per reach lead non-follower reach | [OFFICIAL] / [REPORTED] | Reels Chaining card 2025-11-11; Mosseri 2025-01 |
| 4 | Likes per reach | Like count feeds the "Interested" prediction; likes matter most for follower reach | [OFFICIAL] / [REPORTED] | Reels Chaining card 2025-11-11; Mosseri 2025-01 |
| 5 | Comments | Predicted per viewer, using comment history and recent (past hour) commenting | [OFFICIAL] | Reels Chaining card, 2025-11-11 |
| 6 | Follow the author | Predicts a follow; uses followers the author gained through this reel | [OFFICIAL] | Reels Chaining card, 2025-11-11 |
| 7 | Audio reuse | Predicts the viewer using the reel's audio in their own reel; audio page visits also listed in 2023 | [OFFICIAL] | Reels Chaining card 2025-11-11; Ranking Explained 2023-05-31 |
| 8 | Full-screen open from Explore | Predicts a tap on the tall reel tile in Explore, so the cover frame must pull a click | [OFFICIAL] / [INFERRED] | Reels Chaining card, 2025-11-11 |
| 9 | Sound-on views | Count of sound-on views is an input against early exits | [OFFICIAL] | Reels Chaining card, 2025-11-11 |
| 10 | "Interested" feedback | Predicts tapping Interested when the prompt shows; Not interested filters similar reels | [OFFICIAL] | Reels Chaining card, 2025-11-11 |
| 11 | Length | Used at candidate selection; over 3 minutes means no recommendations to new audiences | [OFFICIAL] | Reels Chaining card 2025-11-11; Reels feature page, read 2026-11-25 |

## Negative signals and penalties
- Reels that are low resolution, carry another app's watermark, are muted, have borders, are mostly text, or were already posted on Instagram may be shown less. [OFFICIAL] Ranking Explained, 2023-05-31
- Originality (2026-04-30): accounts that mainly post unoriginal content lose recommendation eligibility across Instagram. Adding only a border, watermark, subtitles or a caption credit does not make a post original. [OFFICIAL] Instagram Creators blog, 2026-04-30
- What counts as original: you made it, or you edited it meaningfully with new context, information or a point of view (on-image text, graphics, remix; Meta's wording, this skill never adds on-image text, so originality comes from the point of view in the caption). [OFFICIAL] Creators blog, 2026-04-30
- Recovery: a "significant percentage" of photos, carousels and reels over a rolling 30 days must be original; no threshold is published. Account Status shows standing and handles appeals. [OFFICIAL] Creators blog, 2026-04-30
- Instagram says 75% of US recommendations now come from original posts. [OFFICIAL] Creators blog, 2026-04-30
- Reels Chaining removes non-recommendable content before ranking; Feed reduces distribution of problematic content. [OFFICIAL] system cards, 2025-11-11 / 2026-06-29
- Accounts that repeatedly break the rules can lose recommendation eligibility. [OFFICIAL] Ranking Explained, 2023-05-31
- Undisclosed AI-person profiles get limited reach and become non-recommendable (see AI section). [OFFICIAL] Creators blog, 2026-08-31
- Viewer controls: Hide removes the post and limits similar posts; Report leads to less similar content; Reels "Not interested" filters similar reels. [OFFICIAL] Feed card 2026-06-29; Reels Chaining card 2025-11-11
- Hashtag stuffing: captions are being capped at five hashtags (gradual rollout), and Instagram says hashtags do not increase reach. [REPORTED] Social Media Today, 2025-12-18, quoting Instagram
- Engagement bait (comment-to-get, tag-a-friend): no Instagram-specific primary source found in this pass; unverified. [REPORTED]
- Fact-checked posts rated False or Altered are ranked lower under Meta's 2024 labeling policy; current US fact-check program status was not re-checked. [OFFICIAL] Meta newsroom, 2024-04-05

## Format specs and safe zones

### Feed
| Format | Ratios | Length limits | Caption limit / "more" cut-off | Hashtag norms | Alt text |
|--------|--------|---------------|--------------------------------|---------------|----------|
| Single photo | 1.91:1 to 4:5; 1080x1350 (4:5) is the common max [REPORTED]; profile grid shows a 3:4 crop (about 1013x1350 visible of a 1080x1350 post) [REPORTED] | n/a | 2,200 chars; about 125 chars before "more" [REPORTED, unverified officially] | Up to 5 per caption, rolling out [REPORTED 2025-12-18] | Custom alt text in Advanced settings [REPORTED, not re-checked] |
| Carousel | Same as photo [REPORTED] | Up to 20 photos or videos since 2024-08 [REPORTED] | Same as photo | Up to 5 | Per image [REPORTED] |
| In-feed video | Posts as a reel; see Reels [REPORTED] | See Reels | Same | Up to 5 | Not verified |

### Reels
| Format | Ratios | Length limits | Caption limit / "more" cut-off | Hashtag norms | Alt text |
|--------|--------|---------------|--------------------------------|---------------|----------|
| Reel | 9:16, 1080x1920 [REPORTED] | Record and edit up to 20 min; only reels up to 3 min are recommended to new audiences [OFFICIAL, Reels feature page, read 2026-11-25] | 2,200 chars; about 125 before "more" [REPORTED] | Up to 5 [REPORTED 2025-12-18] | Not verified for Reels |
| Trial reel | As reel | As reel | As reel | As reel | As reel; needs a public professional account, 1,000+ followers reported [REPORTED]; scheduling added around 2026-04 [REPORTED, SMT] |

Note: the same Reels feature page also says multi-clip reels run up to 3 minutes, which conflicts with the 20-minute line; treat 3 minutes as the safe ceiling for reach. [OFFICIAL] / [INFERRED]

Safe zones (1080x1920 vertical)
- Top 14% (about 270 px), bottom 35% (about 672 px), 6% each side (about 65 px). These figures come from Meta's Reels ads guidance as relayed by third parties (lilachbullock, hopperhq, billo, adnabu). [REPORTED]
- Ads with a disclaimer: keep the bottom 40% (about 768 px) clear. [REPORTED]
- Meta publishes no organic Reels safe-zone numbers; Ads Manager shows a safe-zone overlay. [REPORTED]
- Older third-party guides use top 220-250 px and bottom 320-340 px; the newer, larger margins are the safer default. [REPORTED] / [INFERRED]
- Grid cover: a 3:4 grid tile of a 9:16 reel shows about the middle 1080x1440, so keep the subject in that band (no cover text; words go in the caption or title). [INFERRED]

## Native formats the platform pushes
- Reels are the main recommendation surface, with their own ranker (Reels Chaining). [OFFICIAL] Reels Chaining card, 2025-11-11
- Carousels get a dedicated swipe-through prediction in Feed, and the cap is 20 items. [OFFICIAL] Feed card 2026-06-29; [REPORTED] PetaPixel 2024-08-09
- Trial Reels for testing with non-followers. [OFFICIAL] Meta newsroom, 2024-12-10
- Attribution tools are the approved way to reuse others' work: collabs, remix, paid partnership, story sharing, reposts. [OFFICIAL] Creators blog, 2026-04-30
- Original audio and audio reuse (use audio). [OFFICIAL] Reels Chaining card, 2025-11-11
- Topic steering via "Your Algorithm"; recommended Feed posts can carry interest labels such as "From Running". A post with a clear single topic is easier to match. [OFFICIAL] Instagram blog 2026-06-10; [INFERRED]
- Muse Image AI effects (30+) in Stories, US first. [OFFICIAL] Meta newsroom, 2026-07-07

## AI-generated content: labels, rules, consequences
- Label triggers: industry indicators (C2PA, IPTC) detected on upload, or self-disclosure at posting. The label is "AI info". [OFFICIAL] Meta newsroom 2024-02-06 (updated 2025-04-01) and 2024-04-05; help.instagram.com/761121959519495
- Since 2024-09-12, content only edited with AI shows the label in the menu; content generated by AI keeps the on-post label. [OFFICIAL] Meta newsroom 2024-04-05, update of 2024-09-12
- Disclosure is required for photorealistic video and realistic audio that were made or altered digitally; Meta may apply penalties if it is missing. [OFFICIAL] Meta newsroom, 2024-02-06
- High-risk deceptive content can get a more prominent label; labeled content stays up unless it breaks other rules. [OFFICIAL] Meta newsroom, 2024-04-05
- Reach: no Meta source says the AI info label itself reduces distribution. Do not score a label as a penalty. [OFFICIAL] (absence) / [INFERRED]
- AI-generated profile label (2026-08-31): profiles that feature an AI-generated person must carry it. Detected unlabeled profiles get limited reach and are non-recommendable; labeled ones see no change. AI-assisted human creators are exempt. Appeals go through Account Status. [OFFICIAL] Creators blog, 2026-08-31; corroborated by TechCrunch and Engadget, same day
- The profile label also shows on that account's posts unless a post already has an AI label. [OFFICIAL] Creators blog, 2026-08-31
- Muse provenance: Muse Image output from the Meta AI app and meta.ai carries the invisible Content Seal watermark. Meta has not said it writes C2PA or IPTC metadata, so whether a Muse image triggers the AI info auto-label on upload is unverified. [OFFICIAL] ai.meta.com 2026-07-07; [INFERRED]
- Older Meta AI photoreal images carried a visible marker, an invisible watermark and IPTC metadata. [OFFICIAL] Meta newsroom, 2024-02-06
- Originality interplay: reposting someone else's AI output without meaningful changes counts as unoriginal under the same rules. [INFERRED] from Creators blog, 2026-04-30
- An optional "AI creator" label was tested in 2026-05. [REPORTED] Engadget, 2026-05

## Ranker's predict-checklist
1. Does the first frame or first second stop a scroll (low skip, few exits under 3 s)? [Reels 2, Feed 5]
2. Will a typical viewer watch longer than most viewers of same-length reels? [Reels 1]
3. Is there a concrete reason to send it to one specific person (useful, funny, news, how-to)? [Feed 3, Reels 3]
4. Would a follower like it on sight, not just a stranger? [Feed 2, Reels 4]
5. For carousels: does every slide earn the next swipe through to the last card? [Feed 4]
6. Does it invite a real comment rather than bait? [Feed 7, Reels 5]
7. Is it clearly original, or meaningfully transformed beyond a border, watermark, subtitles or credit? [Negatives]
8. Is it free of other apps' watermarks, borders, low resolution and muted audio? [Negatives]
9. Is the reel 3 minutes or less, framed 9:16, with text inside the 14/35/6% safe zone? [Specs]
10. Does it use 5 or fewer relevant hashtags and front-load the caption before the "more" cut? [Specs]
11. If it shows a realistic AI person, video or voice, is the AI disclosure in place (and the profile labeled for an AI persona)? [AI section]
12. Is the topic clear enough to match a viewer's "Your Algorithm" interests? [Native formats]

## Primary URLs to re-check
- https://transparency.meta.com/features/explaining-ranking/ig-feed/ - Feed stages, predictions, signals (read 2026-11-25)
- https://transparency.meta.com/features/explaining-ranking/ig-reels-chaining/ - Reels ranking (read 2026-11-25)
- https://transparency.meta.com/features/explaining-ranking/ig-explore/ - Explore ranking (read 2026-11-25)
- https://about.instagram.com/blog/announcements/instagram-ranking-explained - Mosseri ranking explainer, 2023 (read 2026-11-25)
- https://creators.instagram.com/blog/rewarding-original-creators-on-instagram - originality rules (read 2026-11-25)
- https://creators.instagram.com/blog/ai-generated-profile-label - AI persona label and reach limit (read 2026-11-25)
- https://about.instagram.com/features/reels/ - Reels length (read 2026-11-25)
- https://about.fb.com/news/2024/12/trial-reels-try-content-non-followers-first/ - Trial Reels (read 2026-11-25)
- https://about.instagram.com/blog/announcements/reels-algorithm-control - Your Algorithm (read 2026-11-25)
- https://help.instagram.com/761121959519495 - AI label help (read 2026-11-25)
- https://about.fb.com/news/2024/04/metas-approach-to-labeling-ai-generated-content-and-manipulated-media/ - AI info policy (read 2026-11-25)
- https://www.threads.com/@creators/post/DSalXGPCWM4 - hashtag cap announcement (not opened directly; seen via SMT 2025-12-18)
