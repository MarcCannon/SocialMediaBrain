# Installing the Social Media Brain skill

Social Media Brain is a skill that sends a post (image or video plus caption), especially one made with Meta's Muse, past five harsh personas. It then returns a POST, FIX-THEN-POST or KILL verdict, ranked fixes, rewrites and Muse regeneration prompts.

Two rules are built in for baby and kids product brands:
- AI babies showing the product are fine. They are never a veto or a deduction.
- No text goes on the image. Hooks go in the caption, alt text, title field or script. Text printed on the product itself is allowed.

## Which file to use
| Where | File |
|---|---|
| claude.ai or Claude Desktop chat | `social-media-brain.zip` |
| Claude Code | `social-media-brain.skill` (or the unzipped folder) |

## claude.ai / Claude Desktop
1. Open Settings > Capabilities and turn on "Code execution and file creation". On Team or Enterprise plans an admin may need to enable it first.
2. Go to Customize > Skills.
3. Click "+", then "+ Create skill", then "Upload a skill".
4. Pick `social-media-brain.zip`. The zip holds the `social-media-brain` folder at its root, which is what the uploader expects.
5. Toggle the skill on.
6. Turn on web search for the chat. The skill uses it for live trends, and without it the Radar persona is capped at 6/10.

## Claude Code
1. Unzip so you have a folder named `social-media-brain` containing `SKILL.md`. A `.skill` file is a zip, so rename it to `.zip` first if needed.
2. Copy the folder to `~/.claude/skills/` (all projects) or `<project>/.claude/skills/` (one project).
3. Start a new session. The skill appears automatically.

Optional tools for video and crop previews in Claude Code: Python 3, Pillow (`pip install pillow`) and ffmpeg. Without them the skill asks you for frames and screenshots instead.

## How to use it
Drop in the image or video and the caption, then ask something like:
- "Will this trend? Check it for LinkedIn, TikTok and Instagram."
- "Roast this Muse image."
- "Which of these two versions should I post?" (A/B Battle)
- "Here is my Muse prompt. Improve it before I generate." (Pre-flight)
- "Here is how it did: ..." (Post-mortem)

For product posts, tell it what the real garment looks like (colours, cut, prints, closures), or fill in `assets/brand-profile-template.md` once. It checks the image against that description and flags any mismatch.

## Good to know
- Platform rules change. Each platform file has a `last_verified` date, and the skill re-checks anything older than 90 days.
- Scores rank quality. They are never converted into views or engagement numbers.
- Muse Image output carries an invisible Content Seal, not C2PA metadata, so some platforms may not auto-label it. Self-label realistic AI people wherever the platform offers a label.
